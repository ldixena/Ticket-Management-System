using System.ComponentModel.DataAnnotations;

namespace SupportDesk.Models;

public class TicketAttachment
{
    public int Id { get; set; }

    public int TicketId { get; set; }
    public Ticket? Ticket { get; set; }

    /// <summary>Null when the file was attached to the original ticket; set when attached to a reply.</summary>
    public int? TicketMessageId { get; set; }
    public TicketMessage? TicketMessage { get; set; }

    [Required, StringLength(255)]
    public string OriginalFileName { get; set; } = string.Empty;

    /// <summary>Random name on disk. Never derived from user input.</summary>
    [Required, StringLength(64)]
    public string StoredFileName { get; set; } = string.Empty;

    [Required, StringLength(100)]
    public string ContentType { get; set; } = "application/octet-stream";

    public long SizeBytes { get; set; }

    [Required]
    public string UploadedById { get; set; } = string.Empty;
    public ApplicationUser? UploadedBy { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
