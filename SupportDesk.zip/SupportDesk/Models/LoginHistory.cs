using System.ComponentModel.DataAnnotations;

namespace SupportDesk.Models;

public enum LoginEventType
{
    SignedIn = 0,
    Failed = 1,
    LockedOut = 2,
    SignedOut = 3
}

/// <summary>One row per sign-in attempt, lock-out or sign-out, for admins and customers alike.</summary>
public class LoginHistory
{
    public int Id { get; set; }

    /// <summary>Null when the email did not match any account.</summary>
    public string? UserId { get; set; }
    public ApplicationUser? User { get; set; }

    /// <summary>The email that was typed (kept even when no account matches).</summary>
    [Required, StringLength(256)]
    public string Email { get; set; } = string.Empty;

    public LoginEventType EventType { get; set; }

    [StringLength(200)] public string? Reason { get; set; }
    [StringLength(64)] public string? IpAddress { get; set; }
    [StringLength(300)] public string? UserAgent { get; set; }

    /// <summary>Short description such as "Chrome on Windows".</summary>
    [StringLength(100)] public string Device { get; set; } = string.Empty;

    /// <summary>"Web" (browser cookie) or "API" (bearer token).</summary>
    [StringLength(20)] public string Method { get; set; } = "Web";

    /// <summary>Role at the time of the event: Admin, Customer or Unknown.</summary>
    [StringLength(20)] public string UserType { get; set; } = "Unknown";

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
