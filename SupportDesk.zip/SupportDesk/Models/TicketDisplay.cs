namespace SupportDesk.Models;

/// <summary>Small helpers shared by views and emails.</summary>
public static class TicketDisplay
{
    public static string Label(this TicketStatus s) => s switch
    {
        TicketStatus.Open => "Open",
        TicketStatus.InProgress => "In progress",
        TicketStatus.Closed => "Closed",
        _ => s.ToString()
    };

    public static string Css(this TicketStatus s) => s switch
    {
        TicketStatus.Open => "open",
        TicketStatus.InProgress => "progress",
        TicketStatus.Closed => "closed",
        _ => "open"
    };

    public static string Css(this TicketPriority p) => p.ToString().ToLowerInvariant();

    public static string FileSize(this long bytes) => bytes switch
    {
        < 1024 => $"{bytes} B",
        < 1024 * 1024 => $"{bytes / 1024.0:0.#} KB",
        _ => $"{bytes / (1024.0 * 1024.0):0.#} MB"
    };

    public static string Stamp(this DateTime utc) => utc.ToString("dd MMM yyyy, HH:mm") + " UTC";
}
