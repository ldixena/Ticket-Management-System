using Microsoft.AspNetCore.Identity;

namespace SupportDesk.Models;

public class ApplicationUser : IdentityUser
{
    public string FullName { get; set; } = string.Empty;

    [System.ComponentModel.DataAnnotations.StringLength(200)]
    public string? CompanyName { get; set; }

    [System.ComponentModel.DataAnnotations.StringLength(500)]
    public string? Address { get; set; }

    /// <summary>Disabled accounts cannot sign in (web or API). Set by an admin.</summary>
    public bool IsDisabled { get; set; }

    /// <summary>Customer agreed to receive WhatsApp updates. PhoneNumber holds the E.164 number.</summary>
    public bool WhatsAppOptIn { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
