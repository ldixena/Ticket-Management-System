using System.ComponentModel.DataAnnotations;

namespace SupportDesk.Models;

public class TicketMessage
{
    public int Id { get; set; }

    public int TicketId { get; set; }
    public Ticket? Ticket { get; set; }

    [Required]
    public string AuthorId { get; set; } = string.Empty;
    public ApplicationUser? Author { get; set; }

    /// <summary>True when written by an admin / support agent.</summary>
    public bool IsStaff { get; set; }

    [Required, StringLength(4000)]
    public string Body { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public List<TicketAttachment> Attachments { get; set; } = new();
}
