using System.ComponentModel.DataAnnotations;

namespace SupportDesk.Models;

public enum TicketStatus
{
    Open = 0,
    [Display(Name = "In progress")] InProgress = 1,
    Closed = 2
}

public enum TicketPriority
{
    Low = 0,
    Medium = 1,
    High = 2,
    Urgent = 3
}

public class Ticket
{
    public int Id { get; set; }

    /// <summary>Public, unguessable reference such as TKT-7K2QM-X9D4R.</summary>
    [Required, StringLength(20)]
    public string Token { get; set; } = string.Empty;

    [Required]
    public string CustomerId { get; set; } = string.Empty;
    public ApplicationUser? Customer { get; set; }

    public int ProductId { get; set; }
    public Product? Product { get; set; }

    [Required, StringLength(200)]
    public string Subject { get; set; } = string.Empty;

    [Required, StringLength(4000)]
    public string Description { get; set; } = string.Empty;

    public TicketPriority Priority { get; set; } = TicketPriority.Medium;
    public TicketStatus Status { get; set; } = TicketStatus.Open;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? ClosedAt { get; set; }

    public List<TicketMessage> Messages { get; set; } = new();
    public List<TicketAttachment> Attachments { get; set; } = new();
}
