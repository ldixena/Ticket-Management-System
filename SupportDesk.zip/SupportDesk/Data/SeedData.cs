using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using SupportDesk.Models;

namespace SupportDesk.Data;

public static class SeedData
{
    public static async Task InitializeAsync(IServiceProvider services)
    {
        var db = services.GetRequiredService<ApplicationDbContext>();
        var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
        var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();
        var config = services.GetRequiredService<IConfiguration>();

        // Applies the InitialCreate migration (create it first: dotnet ef migrations add InitialCreate).
        await db.Database.MigrateAsync();

        foreach (var role in new[] { Roles.Admin, Roles.Customer })
        {
            if (!await roleManager.RoleExistsAsync(role))
                await roleManager.CreateAsync(new IdentityRole(role));
        }

        // Optional: create the first admin from configuration (user-secrets recommended).
        var adminEmail = config["AdminSeed:Email"];
        var adminPassword = config["AdminSeed:Password"];
        if (!string.IsNullOrWhiteSpace(adminEmail) && !string.IsNullOrWhiteSpace(adminPassword))
        {
            var admin = await userManager.FindByEmailAsync(adminEmail);
            if (admin == null)
            {
                admin = new ApplicationUser
                {
                    UserName = adminEmail,
                    Email = adminEmail,
                    EmailConfirmed = true,
                    FullName = config["AdminSeed:FullName"] ?? "Support Admin"
                };
                var result = await userManager.CreateAsync(admin, adminPassword);
                if (!result.Succeeded) return;
            }
            if (!await userManager.IsInRoleAsync(admin, Roles.Admin))
                await userManager.AddToRoleAsync(admin, Roles.Admin);
        }

        if (!await db.Products.AnyAsync())
        {
            db.Products.AddRange(
                new Product { Name = "Web Portal", Description = "Customer-facing website and account area." },
                new Product { Name = "Mobile App", Description = "iOS and Android applications." },
                new Product { Name = "Billing", Description = "Invoices, payments and subscriptions." });
            await db.SaveChangesAsync();
        }
    }
}
