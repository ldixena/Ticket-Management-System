// Small client for the Support Desk API plus a few DOM helpers. Exposed as window.SD.
(function () {
  'use strict';

  class ApiError extends Error {
    constructor(status, data) {
      super((data && (data.title || data.detail)) || 'Request failed (' + status + ')');
      this.status = status;
      this.data = data || {};
      this.errors = (data && data.errors) || {};
    }
  }

  function csrfToken() {
    var m = document.querySelector('meta[name="csrf-token"]');
    return m ? m.content : '';
  }

  // The browser's sign-in cookie is sent automatically. The anti-forgery header protects it from cross-site requests.
  async function request(method, url, body) {
    var init = {
      method: method,
      credentials: 'same-origin',
      headers: { Accept: 'application/json', 'X-CSRF-TOKEN': csrfToken() }
    };
    if (body instanceof FormData) {
      init.body = body;
    } else if (body !== undefined) {
      init.headers['Content-Type'] = 'application/json';
      init.body = JSON.stringify(body);
    }

    var res = await fetch(url, init);
    var data = null;
    if (res.status !== 204) {
      var ct = res.headers.get('content-type') || '';
      if (ct.indexOf('json') !== -1) {
        try { data = await res.json(); } catch (e) { data = null; }
      }
    }

    if (res.status === 401) {
      location.href = '/Account/Login?returnUrl=' + encodeURIComponent(location.pathname + location.search);
      return new Promise(function () {});
    }
    if (res.status === 429) throw new ApiError(429, { title: 'Too many requests. Wait a minute and try again.' });
    if (!res.ok) throw new ApiError(res.status, data);
    return data;
  }

  var api = {
    get: function (url) { return request('GET', url); },
    post: function (url, body) { return request('POST', url, body); },
    put: function (url, body) { return request('PUT', url, body); }
  };

  // h('div', {class: 'x', onclick: fn}, child, [children]) builds DOM safely (text is never parsed as HTML).
  function h(tag, props) {
    var el = document.createElement(tag);
    Object.keys(props || {}).forEach(function (k) {
      var v = props[k];
      if (v === null || v === undefined || v === false) return;
      if (k === 'class') el.className = v;
      else if (k.indexOf('on') === 0) el.addEventListener(k.slice(2), v);
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, v);
    });
    var kids = Array.prototype.slice.call(arguments, 2).flat(Infinity);
    kids.forEach(function (kid) {
      if (kid === null || kid === undefined || kid === false) return;
      el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    });
    return el;
  }

  function fmtDate(iso) {
    if (!iso) return '';
    return new Date(iso).toLocaleString(undefined, { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  }
  function fmtShort(iso) {
    return new Date(iso).toLocaleString(undefined, { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
  }
  function fmtSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1048576) return (bytes / 1024).toFixed(1).replace(/\.0$/, '') + ' KB';
    return (bytes / 1048576).toFixed(1).replace(/\.0$/, '') + ' MB';
  }

  // ---- flash messages (survive one page change) ----
  var flash = {
    show: function (type, msg) {
      var box = document.getElementById('flash');
      if (!box) return;
      box.replaceChildren(h('div', { class: 'flash ' + (type === 'err' ? 'flash-err' : 'flash-ok'), role: type === 'err' ? 'alert' : 'status' }, msg));
      window.scrollTo({ top: 0, behavior: 'smooth' });
    },
    set: function (type, msg) {
      try { sessionStorage.setItem('sd-flash', JSON.stringify({ type: type, msg: msg })); } catch (e) { /* ignore */ }
    },
    restore: function () {
      try {
        var raw = sessionStorage.getItem('sd-flash');
        if (!raw) return;
        sessionStorage.removeItem('sd-flash');
        var f = JSON.parse(raw);
        flash.show(f.type, f.msg);
      } catch (e) { /* ignore */ }
    }
  };

  // ---- forms ----
  function clearFormErrors(form) {
    form.querySelectorAll('.field-error').forEach(function (e) { e.remove(); });
    var fe = form.querySelector('.form-error');
    if (fe) { fe.hidden = true; fe.textContent = ''; }
  }

  function showFormErrors(form, err) {
    var general = [];
    var errs = err.errors || {};
    Object.keys(errs).forEach(function (key) {
      var msgs = [].concat(errs[key]);
      var el = Array.prototype.find.call(form.elements, function (x) { return x.name && x.name.toLowerCase() === key.toLowerCase(); });
      if (el) {
        var host = el.closest('.field') || el.parentElement;
        host.append(h('span', { class: 'field-error', role: 'alert' }, msgs.join(' ')));
      } else {
        general = general.concat(msgs);
      }
    });
    if (!Object.keys(errs).length) {
      general.push(err.message || 'Something went wrong. Try again.');
    }
    if (general.length) {
      var fe = form.querySelector('.form-error');
      if (fe) { fe.textContent = general.join(' '); fe.hidden = false; }
    }
  }

  function bindForm(form, handler) {
    form.addEventListener('submit', async function (e) {
      e.preventDefault();
      clearFormErrors(form);
      var btn = form.querySelector('button[type=submit]');
      var label = btn ? btn.textContent : '';
      if (btn) { btn.disabled = true; btn.textContent = 'Please wait'; }
      try {
        await handler(form);
      } catch (err) {
        if (err instanceof ApiError) {
          showFormErrors(form, err);
        } else {
          console.error(err);
          showFormErrors(form, { errors: {}, message: 'Network problem. Check your connection and try again.' });
        }
      } finally {
        if (btn) { btn.disabled = false; btn.textContent = label; }
      }
    });
  }

  function formJson(form) {
    var o = {};
    Array.prototype.forEach.call(form.elements, function (el) {
      if (!el.name || el.disabled || el.type === 'file' || el.type === 'submit' || el.type === 'button') return;
      o[el.name] = el.type === 'checkbox' ? el.checked : el.value;
    });
    return o;
  }

  window.SD = {
    api: api, ApiError: ApiError, h: h, flash: flash,
    bindForm: bindForm, formJson: formJson,
    fmtDate: fmtDate, fmtShort: fmtShort, fmtSize: fmtSize
  };
})();
