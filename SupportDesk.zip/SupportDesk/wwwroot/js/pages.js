// Every page is a thin HTML shell. This file loads its data from /api/* and renders it.
(function () {
  'use strict';

  var SD = window.SD;
  var api = SD.api, h = SD.h, flash = SD.flash, bindForm = SD.bindForm, formJson = SD.formJson;
  var fmtDate = SD.fmtDate, fmtShort = SD.fmtShort, fmtSize = SD.fmtSize, ApiError = SD.ApiError;

  var $ = function (sel, root) { return (root || document).querySelector(sel); };
  var qs = new URLSearchParams(location.search);

  var STATUS = { Open: ['Open', 'open'], InProgress: ['In progress', 'progress'], Closed: ['Closed', 'closed'] };

  // ---- small view helpers ----
  function statusBadge(s) {
    var m = STATUS[s] || [s, 'open'];
    return h('span', { class: 'badge st-' + m[1] }, m[0]);
  }
  function prioTag(p) {
    return h('span', { class: 'prio pr-' + p.toLowerCase() }, h('i', { 'aria-hidden': 'true' }), p);
  }
  function tokenChip(t, big) { return h('span', { class: 'token' + (big ? ' token-lg' : '') }, t); }
  function failBox(e) {
    return h('div', { class: 'card note note-warn' }, (e && e.message) || 'Something went wrong. Refresh the page and try again.');
  }
  function emptyCard(title, text, href, label) {
    return h('div', { class: 'empty card' }, h('h2', null, title), h('p', { class: 'muted' }, text),
      href ? h('a', { class: 'btn', href: href }, label) : null);
  }
  function table(headers, rows) {
    return h('table', { class: 'table' },
      h('thead', null, h('tr', null, headers.map(function (x) { return h('th', null, x); }))),
      h('tbody', null, rows));
  }

  function attachmentList(items) {
    if (!items || !items.length) return null;
    return h('ul', { class: 'files' }, items.map(function (a) {
      return h('li', null,
        a.isImage ? h('a', { href: a.url, target: '_blank', rel: 'noopener' },
          h('img', { class: 'thumb', src: a.url, alt: a.fileName, loading: 'lazy' })) : null,
        h('a', { class: 'file-name', href: a.url, target: '_blank', rel: 'noopener' }, a.fileName),
        h('small', { class: 'muted' }, fmtSize(a.sizeBytes)));
    }));
  }

  function message(author, isStaff, when, body, files) {
    return h('article', { class: 'msg ' + (isStaff ? 'staff' : 'mine') },
      h('header', null, h('b', null, author), h('span', { class: 'muted' }, fmtDate(when))),
      h('p', { class: 'body' }, body),
      attachmentList(files));
  }

  function threadNodes(t) {
    var first = message(t.customer ? t.customer.name : 'You', false, t.createdAt, t.description, t.attachments);
    return [first].concat(t.messages.map(function (m) {
      return message(m.author, m.isStaff, m.createdAt, m.body, m.attachments);
    }));
  }

  function renderHead(t) {
    document.title = t.subject + ' - Support Desk';
    $('#head').replaceChildren(
      h('div', null,
        h('h1', null, t.subject),
        h('p', { class: 'meta' }, tokenChip(t.token), h('span', null, t.product), prioTag(t.priority),
          h('span', null, 'Opened ' + fmtDate(t.createdAt)))),
      statusBadge(t.status));
  }

  function mustMatch(data, a, b, field) {
    if (data[a] !== data[b]) throw new ApiError(400, { errors: (function () { var o = {}; o[field] = ['The passwords do not match.']; return o; })() });
  }

  // =====================================================================
  // Account
  // =====================================================================
  function login() {
    bindForm($('#login-form'), async function (form) {
      var user = await api.post('/api/auth/login', formJson(form));
      var ret = qs.get('returnUrl');
      var ok = ret && ret.charAt(0) === '/' && ret.charAt(1) !== '/';
      location.href = ok ? ret : (user.roles.indexOf('Admin') !== -1 ? '/Admin' : '/Tickets');
    });
  }

  function register() {
    bindForm($('#register-form'), async function (form) {
      var data = formJson(form);
      mustMatch(data, 'password', 'confirmPassword', 'confirmPassword');
      delete data.confirmPassword;
      await api.post('/api/auth/register', data);
      location.href = '/Tickets';
    });
  }

  async function profile() {
    var form = $('#profile-form');
    try {
      var me = await api.get('/api/auth/me');
      $('#fullName').value = me.fullName;
      $('#companyName').value = me.companyName || '';
      $('#address').value = me.address || '';
      $('#phoneNumber').value = me.phoneNumber || '';
      form.elements.whatsAppOptIn.checked = me.whatsAppOptIn;
    } catch (e) { form.prepend(failBox(e)); }

    bindForm(form, async function (f) {
      await api.put('/api/auth/profile', formJson(f));
      flash.set('ok', 'Your profile was saved.');
      location.reload();
    });

    ownHistory();
  }

  function changePassword() {
    bindForm($('#password-form'), async function (form) {
      var data = formJson(form);
      mustMatch(data, 'newPassword', 'confirmPassword', 'confirmPassword');
      delete data.confirmPassword;
      await api.post('/api/auth/change-password', data);
      flash.set('ok', 'Your password was changed.');
      location.href = document.body.dataset.admin === 'true' ? '/Admin' : '/Tickets';
    });
  }

  // =====================================================================
  // Customer tickets
  // =====================================================================
  async function ticketsIndex() {
    var box = $('#list');
    try {
      var items = await api.get('/api/tickets');
      if (!items.length) {
        box.replaceChildren(emptyCard('No tickets yet', 'When something goes wrong, raise a ticket and it will show up here.', '/Tickets/Create', 'Raise your first ticket'));
        return;
      }
      box.replaceChildren(h('div', { class: 'card table-wrap' }, table(
        ['Token', 'Subject', 'Product', 'Priority', 'Status', 'Last update'],
        items.map(function (t) {
          return h('tr', null,
            h('td', null, tokenChip(t.token)),
            h('td', null, h('a', { class: 'row-link', href: '/Tickets/Details/' + t.id }, t.subject)),
            h('td', null, t.product),
            h('td', null, prioTag(t.priority)),
            h('td', null, statusBadge(t.status)),
            h('td', { class: 'muted nowrap' }, fmtDate(t.updatedAt)));
        }))));
    } catch (e) { box.replaceChildren(failBox(e)); }
  }

  async function ticketsCreate() {
    var select = $('#productId');
    try {
      var products = await api.get('/api/products');
      select.replaceChildren(h('option', { value: '0' }, products.length ? 'Choose a product' : 'No products are available yet'));
      products.forEach(function (p) { select.append(h('option', { value: p.id }, p.name)); });
    } catch (e) { select.replaceChildren(h('option', { value: '0' }, 'Could not load products')); }

    bindForm($('#ticket-form'), async function (form) {
      var res = await api.post('/api/tickets', new FormData(form));
      flash.set(res.warning ? 'err' : 'ok',
        res.warning || ('Ticket created. Your token is ' + res.token + '. We also emailed it to you.'));
      location.href = '/Tickets/Details/' + res.id;
    });
  }

  async function ticketDetails() {
    var id = $('#app').dataset.id;
    var thread = $('#thread'), form = $('#reply-form'), closed = $('#closed-note');

    function render(t) {
      renderHead(t);
      thread.replaceChildren.apply(thread, threadNodes(t));
      var isClosed = t.status === 'Closed';
      form.hidden = isClosed;
      closed.hidden = !isClosed;
      if (isClosed) {
        closed.replaceChildren('This ticket was closed on ' + fmtDate(t.closedAt) + '. Need more help? ',
          h('a', { href: '/Tickets/Create' }, 'Raise a new ticket'), '.');
      }
    }

    try { render(await api.get('/api/tickets/' + id)); }
    catch (e) { thread.replaceChildren(failBox(e)); return; }

    bindForm(form, async function (f) {
      var t = await api.post('/api/tickets/' + id + '/replies', new FormData(f));
      f.reset();
      render(t);
      flash.show('ok', 'Reply sent.');
    });
  }

  // =====================================================================
  // Track by token (public)
  // =====================================================================
  function trackCard(t) {
    var stage = t.status === 'Open' ? 0 : t.status === 'InProgress' ? 1 : 2;
    var steps = ['Open', 'In progress', 'Closed'];
    return h('section', { class: 'card track-result' },
      h('header', null, tokenChip(t.token, true), statusBadge(t.status)),
      h('ol', { class: 'progress', 'aria-label': 'Ticket progress' },
        steps.map(function (s, i) { return h('li', { class: i <= stage ? 'done' : null }, s); })),
      h('dl', { class: 'facts' },
        h('dt', null, 'Subject'), h('dd', null, t.subject),
        h('dt', null, 'Product'), h('dd', null, t.product),
        h('dt', null, 'Priority'), h('dd', null, prioTag(t.priority)),
        h('dt', null, 'Opened'), h('dd', null, fmtDate(t.createdAt)),
        h('dt', null, 'Last update'), h('dd', null, fmtDate(t.updatedAt))),
      h('p', { class: 'muted' }, 'To read the conversation or reply, ',
        h('a', { href: '/Account/Login?returnUrl=%2FTickets' }, 'sign in'),
        ' with the account that raised this ticket.'));
  }

  function track() {
    var form = $('#track-form'), input = $('#token'), out = $('#result');

    async function lookup(value) {
      out.replaceChildren(h('p', { class: 'muted' }, 'Checking'));
      try {
        var t = await api.get('/api/track/' + encodeURIComponent(value));
        out.replaceChildren(trackCard(t));
      } catch (e) {
        out.replaceChildren(h('div', { class: 'card note note-warn' },
          e.status === 404 ? 'No ticket matches that token. Check for typos. Tokens look like TKT-7K2QM-X9D4R.' : e.message));
      }
    }

    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var v = input.value.trim();
      if (!v) return;
      history.replaceState(null, '', '/track?token=' + encodeURIComponent(v));
      lookup(v);
    });

    var initial = qs.get('token');
    if (initial) { input.value = initial; lookup(initial); }
  }

  // =====================================================================
  // Admin dashboard
  // =====================================================================
  async function adminDashboard() {
    var root = $('#dash');
    var q = qs.get('q') || '';
    var status = qs.get('status') || '';
    var page = parseInt(qs.get('page') || '1', 10) || 1;

    $('#q').value = q;
    $('#status-filter').value = status;

    function url(o) {
      var v = Object.assign({ q: q, status: status, page: 1 }, o);
      var p = new URLSearchParams();
      if (v.q) p.set('q', v.q);
      if (v.status) p.set('status', v.status);
      if (v.page > 1) p.set('page', v.page);
      var s = p.toString();
      return '/Admin' + (s ? '?' + s : '');
    }

    var dash, list;
    try {
      var p = new URLSearchParams({ page: page });
      if (q) p.set('q', q);
      if (status) p.set('status', status);
      var res = await Promise.all([api.get('/api/admin/dashboard'), api.get('/api/admin/tickets?' + p)]);
      dash = res[0]; list = res[1];
    } catch (e) { root.replaceChildren(failBox(e)); return; }

    var pct = function (n) { return dash.total ? (Math.round(n * 1000 / dash.total) / 10) : 0; };

    var stubs = [
      { key: 'Open', num: dash.open, label: 'Open', sub: 'not picked up yet', cls: 's-open' },
      { key: 'InProgress', num: dash.inProgress, label: 'In progress', sub: 'being worked on', cls: 's-progress' },
      { key: 'Closed', num: dash.closed, label: 'Closed', sub: 'resolved', cls: 's-closed' },
      { key: '', num: dash.total, label: 'All tickets', sub: dash.createdToday + ' new today', cls: 's-all' }
    ];

    var tab = function (label, key, count) {
      return h('a', { class: 'tab' + (status === key ? ' on' : ''), href: url({ status: key, page: 1 }) }, label, ' ', h('span', null, count));
    };

    var maxProduct = Math.max.apply(null, [1].concat(dash.products.map(function (x) { return x.total; })));

    var tableCard = h('section', { class: 'card table-card' },
      h('div', { class: 'tabs' },
        tab('All', '', dash.total), tab('Open', 'Open', dash.open),
        tab('In progress', 'InProgress', dash.inProgress), tab('Closed', 'Closed', dash.closed)),
      list.items.length === 0
        ? h('div', { class: 'empty' }, h('h2', null, 'No tickets match'),
            h('p', { class: 'muted' }, 'Try a different search term or switch the status tab.'),
            h('a', { class: 'btn btn-ghost', href: '/Admin' }, 'Clear filters'))
        : [
            h('div', { class: 'table-wrap' }, table(['Token', 'Ticket', 'Priority', 'Status', 'Updated', ''],
              list.items.map(function (t) {
                return h('tr', null,
                  h('td', null, tokenChip(t.token)),
                  h('td', null,
                    h('a', { class: 'row-link', href: '/Admin/Manage/' + t.id }, t.subject),
                    h('div', { class: 'sub' }, t.product + ', ' + (t.customerName || '') + (t.customerCompany ? ' (' + t.customerCompany + ')' : ''))),
                  h('td', null, prioTag(t.priority)),
                  h('td', null, statusBadge(t.status)),
                  h('td', { class: 'muted nowrap' }, fmtShort(t.updatedAt)),
                  h('td', null, h('a', { class: 'btn btn-sm btn-ghost', href: '/Admin/Manage/' + t.id }, 'Manage')));
              }))),
            list.totalPages > 1 ? h('nav', { class: 'pager', 'aria-label': 'Pages' },
              list.page > 1 ? h('a', { class: 'btn btn-sm btn-ghost', href: url({ page: list.page - 1 }) }, 'Previous') : null,
              h('span', { class: 'muted' }, 'Page ' + list.page + ' of ' + list.totalPages + ' (' + list.total + ' tickets)'),
              list.page < list.totalPages ? h('a', { class: 'btn btn-sm btn-ghost', href: url({ page: list.page + 1 }) }, 'Next') : null) : null
          ]);

    var side = h('aside', { class: 'card side-card' },
      h('h2', null, 'By product'),
      dash.products.length === 0
        ? h('p', { class: 'muted' }, 'Add a product to start receiving tickets.')
        : h('ul', { class: 'bars' }, dash.products.map(function (x) {
            return h('li', null,
              h('div', { class: 'bar-head' }, h('span', null, x.name), h('b', null, x.total)),
              h('div', { class: 'meter' }, h('span', { style: 'width:' + (x.total * 100 / maxProduct) + '%' })),
              h('small', { class: 'muted' }, x.unresolved + ' unresolved'));
          })),
      h('a', { class: 'btn btn-sm btn-ghost', href: '/Products' }, 'Manage products'));

    root.replaceChildren(
      dash.urgentUnresolved > 0
        ? h('a', { class: 'alert-strip', href: '/Admin' },
            h('b', null, dash.urgentUnresolved + ' urgent ' + (dash.urgentUnresolved === 1 ? 'ticket is' : 'tickets are') + ' still unresolved.'),
            ' Urgent tickets are listed first.')
        : null,
      h('section', { class: 'stubs', 'aria-label': 'Status totals' }, stubs.map(function (s) {
        return h('a', { class: 'stub ' + s.cls, href: url({ status: s.key, q: '', page: 1 }) },
          h('span', { class: 'stub-num' }, s.num),
          h('span', { class: 'stub-label' }, h('b', null, s.label), h('small', null, s.sub)));
      })),
      h('div', { class: 'dist', role: 'img', 'aria-label': 'Share of tickets by status' },
        h('span', { class: 'd-open', style: 'width:' + pct(dash.open) + '%' }),
        h('span', { class: 'd-progress', style: 'width:' + pct(dash.inProgress) + '%' }),
        h('span', { class: 'd-closed', style: 'width:' + pct(dash.closed) + '%' })),
      h('div', { class: 'dash-grid' }, tableCard, side));
  }

  // =====================================================================
  // Admin: manage ticket
  // =====================================================================
  async function adminManage() {
    var id = $('#app').dataset.id;
    var thread = $('#thread'), form = $('#manage-form');

    function render(t) {
      renderHead(t);
      thread.replaceChildren.apply(thread, threadNodes(t));
      $('#status').value = t.status;
      $('#customer').replaceChildren(
        h('h2', null, 'Customer'),
        h('dl', { class: 'facts' },
          h('dt', null, 'Name'), h('dd', null, t.customer ? t.customer.name : ''),
          h('dt', null, 'Email'), h('dd', null, t.customer ? h('a', { href: 'mailto:' + t.customer.email }, t.customer.email) : ''),
          t.customer && t.customer.companyName ? h('dt', null, 'Company') : null, t.customer && t.customer.companyName ? h('dd', null, t.customer.companyName) : null,
          t.customer && t.customer.address ? h('dt', null, 'Address') : null, t.customer && t.customer.address ? h('dd', { class: 'prewrap' }, t.customer.address) : null,
          t.customer && t.customer.phoneNumber ? h('dt', null, 'Phone') : null, t.customer && t.customer.phoneNumber ? h('dd', null, t.customer.phoneNumber) : null,
          h('dt', null, 'Updated'), h('dd', null, fmtDate(t.updatedAt)),
          t.closedAt ? h('dt', null, 'Closed') : null, t.closedAt ? h('dd', null, fmtDate(t.closedAt)) : null));
    }

    try { render(await api.get('/api/admin/tickets/' + id)); }
    catch (e) { thread.replaceChildren(failBox(e)); return; }

    bindForm(form, async function (f) {
      var t = await api.post('/api/admin/tickets/' + id + '/update', new FormData(f));
      $('#reply').value = '';
      var picker = $('#files'); if (picker) picker.value = '';
      render(t);
      flash.show('ok', 'Ticket updated and the customer was notified.');
    });
  }

  // =====================================================================
  // Admin: products
  // =====================================================================
  async function productsIndex() {
    var box = $('#list');

    async function load() {
      var items;
      try { items = await api.get('/api/admin/products'); }
      catch (e) { box.replaceChildren(failBox(e)); return; }

      if (!items.length) {
        box.replaceChildren(emptyCard('No products yet', 'Customers choose a product when they raise a ticket, so add at least one.', '/Products/Create', 'Add a product'));
        return;
      }

      box.replaceChildren(h('div', { class: 'card table-wrap' }, table(['Product', 'Tickets', 'Visibility', ''],
        items.map(function (p) {
          return h('tr', { class: p.isActive ? null : 'dim' },
            h('td', null, h('b', null, p.name), p.description ? h('div', { class: 'sub' }, p.description) : null),
            h('td', null, p.ticketCount),
            h('td', null, h('span', { class: 'badge ' + (p.isActive ? 'st-progress' : 'st-closed') }, p.isActive ? 'Active' : 'Hidden')),
            h('td', { class: 'actions-cell' },
              h('a', { class: 'btn btn-sm btn-ghost', href: '/Products/Edit/' + p.id }, 'Edit'),
              h('button', {
                type: 'button', class: 'btn btn-sm btn-ghost',
                onclick: async function () {
                  try {
                    var r = await api.post('/api/admin/products/' + p.id + '/toggle');
                    flash.show('ok', r.isActive ? r.name + ' is active.' : r.name + ' is hidden from customers.');
                    await load();
                  } catch (e) { flash.show('err', errText(e)); }
                }
              }, p.isActive ? 'Deactivate' : 'Activate')));
        }))));
    }

    await load();
  }

  async function productsForm() {
    var id = $('#app').dataset.id;
    var form = $('#product-form');

    if (id) {
      try {
        var p = await api.get('/api/admin/products/' + id);
        form.querySelector('[name=name]').value = p.name;
        form.querySelector('[name=description]').value = p.description || '';
        form.querySelector('[name=isActive]').checked = p.isActive;
      } catch (e) { form.prepend(failBox(e)); }
    }

    bindForm(form, async function (f) {
      var data = formJson(f);
      if (id) await api.put('/api/admin/products/' + id, data);
      else await api.post('/api/admin/products', data);
      flash.set('ok', id ? 'Product saved.' : 'Product added.');
      location.href = '/Products';
    });
  }

  // =====================================================================
  // =====================================================================
  // Shared helpers for lists
  // =====================================================================
  var EVENT = {
    SignedIn: ['Signed in', 'ev-ok'], Failed: ['Failed attempt', 'ev-fail'],
    LockedOut: ['Locked out', 'ev-fail'], SignedOut: ['Signed out', 'ev-out']
  };
  function eventBadge(ev) {
    var m = EVENT[ev] || [ev, 'ev-out'];
    return h('span', { class: 'badge ' + m[1] }, m[0]);
  }
  function errText(e) {
    var keys = e && e.errors ? Object.keys(e.errors) : [];
    if (keys.length) return [].concat(e.errors[keys[0]])[0];
    return (e && e.message) || 'Something went wrong.';
  }
  function listUrl(base, params) {
    var p = new URLSearchParams();
    Object.keys(params).forEach(function (k) { if (params[k]) p.set(k, params[k]); });
    var s = p.toString();
    return base + (s ? '?' + s : '');
  }
  function pager(list, hrefFor) {
    if (list.totalPages <= 1) return null;
    return h('nav', { class: 'pager', 'aria-label': 'Pages' },
      list.page > 1 ? h('a', { class: 'btn btn-sm btn-ghost', href: hrefFor(list.page - 1) }, 'Previous') : null,
      h('span', { class: 'muted' }, 'Page ' + list.page + ' of ' + list.totalPages + ' (' + list.total + ' records)'),
      list.page < list.totalPages ? h('a', { class: 'btn btn-sm btn-ghost', href: hrefFor(list.page + 1) }, 'Next') : null);
  }
  function randomPassword() {
    var sets = ['ABCDEFGHJKLMNPQRSTUVWXYZ', 'abcdefghijkmnopqrstuvwxyz', '23456789'];
    var all = sets.join('');
    var pick = function (chars) { var b = new Uint32Array(1); crypto.getRandomValues(b); return chars[b[0] % chars.length]; };
    var out = sets.map(pick);
    while (out.length < 14) out.push(pick(all));
    for (var i = out.length - 1; i > 0; i--) {           // shuffle
      var b = new Uint32Array(1); crypto.getRandomValues(b);
      var j = b[0] % (i + 1); var t = out[i]; out[i] = out[j]; out[j] = t;
    }
    return out.join('');
  }

  // =====================================================================
  // Sign-in history (own) on the profile page
  // =====================================================================
  async function ownHistory() {
    var box = $('#history');
    try {
      var list = await api.get('/api/auth/login-history');
      if (!list.items.length) { box.replaceChildren(h('p', { class: 'muted' }, 'No sign-ins recorded yet.')); return; }
      box.replaceChildren(h('div', { class: 'card table-wrap' }, table(['When', 'Event', 'IP address', 'Device', 'Via'],
        list.items.map(function (x) {
          return h('tr', null,
            h('td', { class: 'nowrap' }, fmtDate(x.createdAt)),
            h('td', null, eventBadge(x.event), x.reason && x.event !== 'SignedIn' ? h('div', { class: 'sub' }, x.reason) : null),
            h('td', null, h('span', { class: 'mono' }, x.ipAddress || 'unknown')),
            h('td', null, x.device),
            h('td', null, x.method));
        }))),
        list.total > list.items.length ? h('p', { class: 'muted' }, 'Showing the latest ' + list.items.length + ' of ' + list.total + '.') : null);
    } catch (e) { box.replaceChildren(failBox(e)); }
  }

  // =====================================================================
  // Admin: users and admins
  // =====================================================================
  async function adminUsers() {
    var q = qs.get('q') || '', role = qs.get('role') || '', page = parseInt(qs.get('page') || '1', 10) || 1;
    $('#q').value = q; $('#role').value = role;

    var box = $('#list'), resetCard = $('#reset-card'), resetForm = $('#reset-form');
    var me;
    try { me = await api.get('/api/auth/me'); } catch (e) { box.replaceChildren(failBox(e)); return; }

    var href = function (p) { return listUrl('/Admin/Users', { q: q, role: role, page: p > 1 ? p : '' }); };

    async function act(u, path, okMsg) {
      try { await api.post('/api/admin/users/' + u.id + '/' + path); flash.show('ok', okMsg); await load(); }
      catch (e) { flash.show('err', errText(e)); }
    }

    function openReset(u) {
      resetCard.hidden = false;
      resetCard.dataset.userId = u.id;
      $('#reset-name').textContent = u.fullName + ' (' + u.email + ')';
      $('#newPassword').value = '';
      $('#generated').hidden = true;
      resetCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
      $('#newPassword').focus();
    }

    async function load() {
      var list;
      try { list = await api.get('/api/admin/users?' + new URLSearchParams({ q: q, role: role, page: page })); }
      catch (e) { box.replaceChildren(failBox(e)); return; }

      if (!list.items.length) {
        box.replaceChildren(emptyCard('No users match', 'Try a different search.', '/Admin/Users', 'Clear filters'));
        return;
      }

      box.replaceChildren(h('div', { class: 'card table-card' },
        h('div', { class: 'table-wrap' }, table(['User', 'Company', 'Role', 'Last sign-in', 'Tickets', 'Status', ''],
          list.items.map(function (u) {
            var isAdmin = u.roles.indexOf('Admin') !== -1, self = u.id === me.id;
            return h('tr', { class: u.isDisabled ? 'dim' : null },
              h('td', null, h('b', null, u.fullName), self ? h('span', { class: 'muted' }, ' (you)') : null, h('div', { class: 'sub' }, u.email)),
              h('td', null, u.companyName || '', u.address ? h('div', { class: 'sub' }, u.address) : null),
              h('td', null, h('span', { class: 'badge ' + (isAdmin ? 'st-open' : 'st-closed') }, isAdmin ? 'Admin' : 'Customer')),
              h('td', { class: 'muted nowrap' }, u.lastSignInAt ? fmtDate(u.lastSignInAt) : 'Never'),
              h('td', null, u.ticketCount),
              h('td', null, h('span', { class: 'badge ' + (u.isDisabled ? 'ev-fail' : 'ev-ok') }, u.isDisabled ? 'Disabled' : 'Active')),
              h('td', { class: 'actions-cell wrap' },
                isAdmin
                  ? h('button', { type: 'button', class: 'btn btn-sm btn-ghost', disabled: self,
                      onclick: function () { act(u, 'remove-admin', u.fullName + ' is no longer an admin.'); } }, 'Remove admin')
                  : h('button', { type: 'button', class: 'btn btn-sm btn-ghost',
                      onclick: function () { act(u, 'make-admin', u.fullName + ' is now an admin. They need to sign in again.'); } }, 'Make admin'),
                h('button', { type: 'button', class: 'btn btn-sm btn-ghost', disabled: self, onclick: function () { openReset(u); } }, 'Reset password'),
                u.isDisabled
                  ? h('button', { type: 'button', class: 'btn btn-sm btn-ghost',
                      onclick: function () { act(u, 'enable', u.fullName + ' can sign in again.'); } }, 'Enable')
                  : h('button', { type: 'button', class: 'btn btn-sm btn-ghost', disabled: self,
                      onclick: function () { act(u, 'disable', u.fullName + ' is disabled and signed out.'); } }, 'Disable')));
          }))),
        pager(list, href)));
    }

    bindForm($('#admin-form'), async function (f) {
      var u = await api.post('/api/admin/users', formJson(f));
      f.reset();
      f.closest('details').open = false;
      flash.show('ok', u.fullName + ' is now an admin. Share the temporary password securely.');
      await load();
    });

    bindForm(resetForm, async function (f) {
      await api.post('/api/admin/users/' + resetCard.dataset.userId + '/reset-password', { newPassword: f.elements.newPassword.value });
      resetCard.hidden = true;
      flash.show('ok', 'Password reset. Share the new password directly. The user was signed out and emailed.');
    });

    $('#generate').addEventListener('click', function () {
      var pw = randomPassword();
      $('#newPassword').value = pw;
      var g = $('#generated');
      g.hidden = false;
      g.replaceChildren('Generated: ', h('code', null, pw));
    });
    $('#reset-cancel').addEventListener('click', function () { resetCard.hidden = true; });

    await load();
  }

  // =====================================================================
  // Admin: login history (everyone)
  // =====================================================================
  async function adminLogins() {
    var q = qs.get('q') || '', outcome = qs.get('outcome') || '', userType = qs.get('userType') || '';
    var page = parseInt(qs.get('page') || '1', 10) || 1;
    $('#q').value = q; $('#outcome').value = outcome; $('#userType').value = userType;
    var box = $('#list');

    var href = function (p) { return listUrl('/Admin/LoginHistory', { q: q, outcome: outcome, userType: userType, page: p > 1 ? p : '' }); };

    try {
      var list = await api.get('/api/admin/login-history?' + new URLSearchParams({ q: q, outcome: outcome, userType: userType, page: page }));
      if (!list.items.length) {
        box.replaceChildren(emptyCard('No records match', 'Try a different search or filter.', '/Admin/LoginHistory', 'Clear filters'));
        return;
      }
      box.replaceChildren(h('div', { class: 'card table-card' },
        h('div', { class: 'table-wrap' }, table(['When', 'User', 'Type', 'Event', 'IP address', 'Device', 'Via'],
          list.items.map(function (x) {
            return h('tr', null,
              h('td', { class: 'nowrap' }, fmtDate(x.createdAt)),
              h('td', null, x.userName ? h('b', null, x.userName) : h('span', { class: 'muted' }, 'No account'), h('div', { class: 'sub' }, x.email)),
              h('td', null, h('span', { class: 'badge ' + (x.userType === 'Admin' ? 'st-open' : 'st-closed') }, x.userType)),
              h('td', null, eventBadge(x.event), x.reason && x.event !== 'SignedIn' ? h('div', { class: 'sub' }, x.reason) : null),
              h('td', null, h('span', { class: 'mono' }, x.ipAddress || 'unknown')),
              h('td', null, x.device),
              h('td', null, x.method));
          }))),
        pager(list, href)));
    } catch (e) { box.replaceChildren(failBox(e)); }
  }

  // =====================================================================
  // Admin: ticket report
  // =====================================================================
  async function adminReports() {
    var keys = ['status', 'from', 'to', 'productId', 'priority', 'q'];
    var f = {};
    keys.forEach(function (k) { f[k] = qs.get(k) || ''; });
    var page = parseInt(qs.get('page') || '1', 10) || 1;
    var out = $('#report');

    try {
      var products = await api.get('/api/admin/products');
      products.forEach(function (p) { $('#productId').append(h('option', { value: p.id }, p.name)); });
    } catch (e) { /* the report still works without the product list */ }
    keys.forEach(function (k) { var el = $('#' + k); if (el) el.value = f[k]; });

    function params(extra) {
      var p = new URLSearchParams();
      keys.forEach(function (k) { if (f[k]) p.set(k, f[k]); });
      Object.keys(extra || {}).forEach(function (k) { if (extra[k]) p.set(k, extra[k]); else p.delete(k); });
      return p;
    }
    var href = function (p) { return '/Admin/Reports?' + params({ page: p > 1 ? p : '' }); };

    $('#csv-link').href = '/api/admin/reports/tickets.csv?' + params();
    $('#print-btn').addEventListener('click', function () { window.print(); });

    var r;
    try { r = await api.get('/api/admin/reports/tickets?' + params({ page: page > 1 ? page : '' })); }
    catch (e) { out.replaceChildren(failBox(e)); return; }

    var s = r.summary;
    var stubs = [
      { key: 'Open', num: s.open, label: 'Open', cls: 's-open' },
      { key: 'InProgress', num: s.inProgress, label: 'In progress', cls: 's-progress' },
      { key: 'Closed', num: s.closed, label: 'Closed', cls: 's-closed' },
      { key: '', num: s.total, label: 'All tickets', cls: 's-all' }
    ];

    var scope = f.status ? (STATUS[f.status] ? STATUS[f.status][0].toLowerCase() : f.status) + ' tickets' : 'tickets';
    var maxPrio = Math.max.apply(null, [1].concat(r.byPriority.map(function (x) { return x.count; })));

    out.replaceChildren(
      h('section', { class: 'stubs', 'aria-label': 'Totals for these filters' }, stubs.map(function (x) {
        return h('a', { class: 'stub no-link-print ' + x.cls, href: '/Admin/Reports?' + params({ status: x.key, page: '' }) },
          h('span', { class: 'stub-num' }, x.num),
          h('span', { class: 'stub-label' }, h('b', null, x.label), h('small', null, x.key === f.status ? 'showing these' : 'show these')));
      })),
      h('p', { class: 'report-note' },
        h('b', null, s.matching), ' ' + scope + ' match your filters.',
        s.avgResolutionHours !== null && s.avgResolutionHours !== undefined
          ? ' Average time to close: ' + s.avgResolutionHours + ' hours.' : ''),
      h('div', { class: 'dash-grid' },
        h('section', { class: 'card table-card' },
          r.rows.items.length === 0
            ? h('div', { class: 'empty' }, h('h2', null, 'No tickets match'), h('p', { class: 'muted' }, 'Widen the dates or clear a filter.'))
            : [
                h('div', { class: 'table-wrap' }, table(['Token', 'Subject', 'Product', 'Priority', 'Status', 'Customer', 'Created', 'Closed'],
                  r.rows.items.map(function (t) {
                    return h('tr', null,
                      h('td', null, tokenChip(t.token)),
                      h('td', null, h('a', { class: 'row-link', href: '/Admin/Manage/' + t.id }, t.subject)),
                      h('td', null, t.product),
                      h('td', null, prioTag(t.priority)),
                      h('td', null, statusBadge(t.status)),
                      h('td', null, t.customer, t.company ? h('div', { class: 'sub' }, t.company) : null),
                      h('td', { class: 'muted nowrap' }, fmtShort(t.createdAt)),
                      h('td', { class: 'muted nowrap' }, t.closedAt ? fmtShort(t.closedAt) : ''));
                  }))),
                pager(r.rows, href)
              ]),
        h('aside', { class: 'card side-card' },
          h('h2', null, 'By priority'),
          r.byPriority.length === 0
            ? h('p', { class: 'muted' }, 'Nothing to show.')
            : h('ul', { class: 'bars' }, r.byPriority.map(function (x) {
                return h('li', null,
                  h('div', { class: 'bar-head' }, h('span', null, x.priority), h('b', null, x.count)),
                  h('div', { class: 'meter' }, h('span', { style: 'width:' + (x.count * 100 / maxPrio) + '%' })));
              })))));
  }

  var pages = {
    'login': login, 'register': register, 'profile': profile, 'change-password': changePassword,
    'tickets-index': ticketsIndex, 'tickets-create': ticketsCreate, 'tickets-details': ticketDetails,
    'track': track,
    'admin-dashboard': adminDashboard, 'admin-manage': adminManage,
    'products-index': productsIndex, 'products-form': productsForm,
    'admin-users': adminUsers, 'admin-logins': adminLogins, 'admin-reports': adminReports
  };

  document.querySelectorAll('[data-logout]').forEach(function (btn) {
    btn.addEventListener('click', async function () {
      try { await api.post('/api/auth/logout'); } catch (e) { /* session may already be gone */ }
      location.href = '/';
    });
  });

  flash.restore();
  var init = pages[document.body.dataset.page];
  if (init) init();
})();
