using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.Options;
using SupportDesk.Data;
using SupportDesk.Models;

namespace SupportDesk.Services;

public interface IAttachmentService
{
    /// <summary>Returns a user-facing error message, or null when every file is acceptable.</summary>
    string? Validate(IEnumerable<IFormFile>? files);

    Task SaveAsync(IEnumerable<IFormFile>? files, int ticketId, int? messageId, string uploadedById, CancellationToken ct = default);

    Stream? Open(TicketAttachment attachment);

    /// <summary>True for types that are safe to show in the browser (images and PDF). Everything else downloads.</summary>
    bool IsInline(string contentType);
}

public class AttachmentService : IAttachmentService
{
    // Any file type is accepted except ones that run code or render active content in a browser.
    private static readonly HashSet<string> Blocked = new(StringComparer.OrdinalIgnoreCase)
    {
        ".exe", ".dll", ".bat", ".cmd", ".com", ".msi", ".scr", ".cpl", ".pif", ".lnk", ".reg", ".msc",
        ".ps1", ".psm1", ".vbs", ".vbe", ".js", ".jse", ".wsf", ".hta", ".jar", ".sh", ".apk", ".app",
        ".php", ".asp", ".aspx", ".cshtml", ".html", ".htm", ".xhtml", ".svg"
    };

    private static readonly HashSet<string> Inline = new(StringComparer.OrdinalIgnoreCase)
    {
        "image/png", "image/jpeg", "image/gif", "image/webp", "application/pdf"
    };

    private static readonly FileExtensionContentTypeProvider Mime = new();

    private readonly ApplicationDbContext _db;
    private readonly AttachmentSettings _settings;
    private readonly string _root;

    public AttachmentService(ApplicationDbContext db, IOptions<AttachmentSettings> settings, IWebHostEnvironment env)
    {
        _db = db;
        _settings = settings.Value;
        _root = Path.IsPathRooted(_settings.RootPath)
            ? _settings.RootPath
            : Path.Combine(env.ContentRootPath, _settings.RootPath);
    }

    public string? Validate(IEnumerable<IFormFile>? files)
    {
        var list = NonEmpty(files);
        if (list.Count == 0) return null;

        if (list.Count > _settings.MaxFilesPerUpload)
            return $"Attach at most {_settings.MaxFilesPerUpload} files at a time.";

        var maxBytes = _settings.MaxFileSizeMb * 1024L * 1024L;
        foreach (var f in list)
        {
            var name = Path.GetFileName(f.FileName);
            if (string.IsNullOrWhiteSpace(name) || name.Length > 200)
                return "File names must be between 1 and 200 characters.";
            if (Blocked.Contains(Path.GetExtension(name)))
                return $"{name}: this file type is not allowed. Zip it first if you need to send it.";
            if (f.Length > maxBytes)
                return $"{name} is larger than {_settings.MaxFileSizeMb} MB.";
        }
        return null;
    }

    public async Task SaveAsync(IEnumerable<IFormFile>? files, int ticketId, int? messageId,
        string uploadedById, CancellationToken ct = default)
    {
        var list = NonEmpty(files);
        if (list.Count == 0) return;

        var dir = Path.Combine(_root, ticketId.ToString());
        Directory.CreateDirectory(dir);

        foreach (var f in list)
        {
            var name = Path.GetFileName(f.FileName);
            var stored = Guid.NewGuid().ToString("N");

            await using (var target = File.Create(Path.Combine(dir, stored)))
                await f.CopyToAsync(target, ct);

            _db.TicketAttachments.Add(new TicketAttachment
            {
                TicketId = ticketId,
                TicketMessageId = messageId,
                OriginalFileName = name,
                StoredFileName = stored,
                // Decided from the extension on our side, never from the client's Content-Type header.
                ContentType = Mime.TryGetContentType(name, out var type) ? type : "application/octet-stream",
                SizeBytes = f.Length,
                UploadedById = uploadedById
            });
        }

        await _db.SaveChangesAsync(ct);
    }

    public Stream? Open(TicketAttachment attachment)
    {
        var path = Path.Combine(_root, attachment.TicketId.ToString(), attachment.StoredFileName);
        return File.Exists(path) ? File.OpenRead(path) : null;
    }

    public bool IsInline(string contentType) => Inline.Contains(contentType);

    private static List<IFormFile> NonEmpty(IEnumerable<IFormFile>? files) =>
        files?.Where(f => f.Length > 0).ToList() ?? new List<IFormFile>();
}
