using Microsoft.AspNetCore.Identity;
using SupportDesk.Data;
using SupportDesk.Models;

namespace SupportDesk.Services;

public interface ILoginHistoryService
{
    Task RecordAsync(HttpContext http, ApplicationUser? user, string email, LoginEventType type,
        string method, string? reason = null);
}

public class LoginHistoryService : ILoginHistoryService
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _users;
    private readonly ILogger<LoginHistoryService> _logger;

    public LoginHistoryService(ApplicationDbContext db, UserManager<ApplicationUser> users,
        ILogger<LoginHistoryService> logger)
    {
        _db = db;
        _users = users;
        _logger = logger;
    }

    public async Task RecordAsync(HttpContext http, ApplicationUser? user, string email, LoginEventType type,
        string method, string? reason = null)
    {
        try
        {
            var agent = http.Request.Headers.UserAgent.ToString();
            var userType = user == null
                ? "Unknown"
                : await _users.IsInRoleAsync(user, Roles.Admin) ? "Admin" : "Customer";

            _db.LoginHistories.Add(new LoginHistory
            {
                UserId = user?.Id,
                Email = Truncate(email, 256) ?? "",
                EventType = type,
                Reason = Truncate(reason, 200),
                IpAddress = http.Connection.RemoteIpAddress?.ToString(),
                UserAgent = Truncate(agent, 300),
                Device = DeviceParser.Describe(agent),
                Method = method,
                UserType = userType,
                CreatedAt = DateTime.UtcNow
            });
            await _db.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            // Never block a sign-in because the audit row failed.
            _logger.LogError(ex, "Could not record login history for {Email}", email);
        }
    }

    private static string? Truncate(string? s, int max) =>
        s == null ? null : (s.Length <= max ? s : s[..max]);
}

/// <summary>Turns a User-Agent header into something readable, such as "Chrome on Windows".</summary>
public static class DeviceParser
{
    public static string Describe(string? ua)
    {
        if (string.IsNullOrWhiteSpace(ua)) return "API client";

        var browser =
            ua.Contains("Edg/") ? "Edge" :
            ua.Contains("OPR/") || ua.Contains("Opera") ? "Opera" :
            ua.Contains("Firefox/") ? "Firefox" :
            ua.Contains("Chrome/") || ua.Contains("CriOS/") ? "Chrome" :
            ua.Contains("Safari/") ? "Safari" : null;

        var os =
            ua.Contains("Windows") ? "Windows" :
            ua.Contains("Android") ? "Android" :
            ua.Contains("iPhone") || ua.Contains("iPad") ? "iOS" :
            ua.Contains("Mac OS X") || ua.Contains("Macintosh") ? "macOS" :
            ua.Contains("Linux") ? "Linux" : null;

        if (browser != null) return os != null ? $"{browser} on {os}" : browser;

        // Tools such as curl or Postman: show the product name.
        var first = ua.Split(' ', '/')[0];
        return first.Length > 40 ? first[..40] : first;
    }
}
