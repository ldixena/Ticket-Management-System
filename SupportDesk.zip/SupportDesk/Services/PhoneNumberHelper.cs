using SupportDesk.Models;

namespace SupportDesk.Services;

public static class PhoneNumberHelper
{
    /// <summary>
    /// Returns digits only in international format (no +), or null when the input is not a plausible number.
    /// Numbers typed without a leading + get the default country code.
    /// </summary>
    public static string? Normalize(string? input, string? defaultCountryCode)
    {
        if (string.IsNullOrWhiteSpace(input)) return null;

        var trimmed = input.Trim();
        var hasPlus = trimmed.StartsWith('+');
        var digits = new string(trimmed.Where(char.IsDigit).ToArray());
        if (digits.Length == 0) return null;

        if (!hasPlus)
        {
            digits = digits.TrimStart('0');
            if (!string.IsNullOrEmpty(defaultCountryCode) && digits.Length <= 10)
                digits = defaultCountryCode + digits;
        }

        return digits.Length is >= 8 and <= 15 ? digits : null;
    }

    /// <summary>The digits to message, or null when the customer has not opted in to WhatsApp.</summary>
    public static string? WhatsAppTarget(this ApplicationUser? user)
    {
        if (user == null || !user.WhatsAppOptIn || string.IsNullOrWhiteSpace(user.PhoneNumber)) return null;
        var digits = new string(user.PhoneNumber.Where(char.IsDigit).ToArray());
        return digits.Length >= 8 ? digits : null;
    }
}
