using System.Net.Http.Headers;
using System.Net.Http.Json;
using Microsoft.Extensions.Options;

namespace SupportDesk.Services;

public interface IWhatsAppService
{
    bool IsEnabled { get; }

    /// <summary>Sends an approved template message. Parameters fill {{1}}, {{2}}... in order.</summary>
    Task SendTemplateAsync(string toDigits, string templateName, IReadOnlyList<string> parameters, CancellationToken ct = default);
}

/// <summary>WhatsApp Business Cloud API (Meta). Failures are logged and never break the ticket workflow.</summary>
public class WhatsAppService : IWhatsAppService
{
    private readonly HttpClient _http;
    private readonly WhatsAppSettings _settings;
    private readonly ILogger<WhatsAppService> _logger;

    public WhatsAppService(HttpClient http, IOptions<WhatsAppSettings> settings, ILogger<WhatsAppService> logger)
    {
        _http = http;
        _settings = settings.Value;
        _logger = logger;
    }

    public bool IsEnabled =>
        _settings.Enabled &&
        !string.IsNullOrWhiteSpace(_settings.AccessToken) &&
        !string.IsNullOrWhiteSpace(_settings.PhoneNumberId);

    public async Task SendTemplateAsync(string toDigits, string templateName, IReadOnlyList<string> parameters,
        CancellationToken ct = default)
    {
        if (!IsEnabled || string.IsNullOrWhiteSpace(toDigits)) return;

        try
        {
            var payload = new
            {
                messaging_product = "whatsapp",
                to = toDigits,
                type = "template",
                template = new
                {
                    name = templateName,
                    language = new { code = _settings.TemplateLanguage },
                    components = new[]
                    {
                        new
                        {
                            type = "body",
                            parameters = parameters.Select(p => new { type = "text", text = p }).ToArray()
                        }
                    }
                }
            };

            var url = $"https://graph.facebook.com/{_settings.ApiVersion}/{_settings.PhoneNumberId}/messages";
            using var request = new HttpRequestMessage(HttpMethod.Post, url)
            {
                Content = JsonContent.Create(payload)
            };
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _settings.AccessToken);

            using var response = await _http.SendAsync(request, ct);
            if (!response.IsSuccessStatusCode)
            {
                var body = await response.Content.ReadAsStringAsync(ct);
                _logger.LogError("WhatsApp send failed ({Status}) for template {Template}: {Body}",
                    (int)response.StatusCode, templateName, body);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "WhatsApp send failed for template {Template}", templateName);
        }
    }
}
