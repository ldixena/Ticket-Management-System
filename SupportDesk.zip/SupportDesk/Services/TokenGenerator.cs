using System.Security.Cryptography;
using Microsoft.EntityFrameworkCore;
using SupportDesk.Data;

namespace SupportDesk.Services;

public static class TokenGenerator
{
    // No 0/O or 1/I so tokens survive being read aloud or retyped.
    private const string Alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

    /// <summary>Returns a cryptographically random token like TKT-7K2QM-X9D4R (about 50 bits of entropy).</summary>
    public static string Create()
    {
        static string Block(int length)
        {
            var chars = new char[length];
            for (var i = 0; i < length; i++)
                chars[i] = Alphabet[RandomNumberGenerator.GetInt32(Alphabet.Length)];
            return new string(chars);
        }
        return $"TKT-{Block(5)}-{Block(5)}";
    }

    public static async Task<string> CreateUniqueAsync(ApplicationDbContext db)
    {
        string token;
        do { token = Create(); }
        while (await db.Tickets.AnyAsync(t => t.Token == token));
        return token;
    }

    public static string Normalize(string input) => input.Trim().ToUpperInvariant();
}
