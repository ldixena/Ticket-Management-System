namespace SupportDesk.Services;

public class AttachmentSettings
{
    /// <summary>Folder for uploaded files. Relative paths are resolved against the app's content root. Keep it outside wwwroot.</summary>
    public string RootPath { get; set; } = "App_Data/uploads";

    public int MaxFileSizeMb { get; set; } = 10;
    public int MaxFilesPerUpload { get; set; } = 5;
}
