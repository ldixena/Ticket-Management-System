using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Options;
using SupportDesk.Models;

namespace SupportDesk.Services;

/// <summary>Builds and sends every notification (email and WhatsApp). Ticket.Product must be loaded.</summary>
public class TicketNotifier
{
    private readonly IEmailService _email;
    private readonly IWhatsAppService _whatsApp;
    private readonly SmtpSettings _settings;
    private readonly WhatsAppSettings _wa;

    public TicketNotifier(IEmailService email, IWhatsAppService whatsApp,
        IOptions<SmtpSettings> settings, IOptions<WhatsAppSettings> waSettings)
    {
        _email = email;
        _whatsApp = whatsApp;
        _settings = settings.Value;
        _wa = waSettings.Value;
    }

    /// <param name="whatsAppTo">Digits to message, or null when the customer has not opted in.</param>
    public async Task TicketCreatedAsync(Ticket t, string customerEmail, string customerName,
        string trackUrl, string manageUrl, string? whatsAppTo = null)
    {
        var customerBody =
            $"<p>Hi {E(customerName)},</p>" +
            "<p>We have your request and the team will reply soon.</p>" +
            Facts(t) +
            $"<p>Your ticket token is <b style=\"font-size:16px;letter-spacing:1px\">{t.Token}</b>. " +
            "Anyone who has it can see the status of this ticket, so share it carefully.</p>";

        await _email.SendAsync(customerEmail, $"[{t.Token}] We received your ticket",
            Wrap("Ticket received", customerBody, trackUrl, "Track this ticket"));

        if (!string.IsNullOrWhiteSpace(_settings.SupportInbox))
        {
            var staffBody =
                $"<p>{E(customerName)} ({E(customerEmail)}) raised a new ticket.</p>" +
                Facts(t) +
                $"<p>{Multiline(t.Description)}</p>";

            await _email.SendAsync(_settings.SupportInbox, $"[{t.Token}] New ticket: {t.Subject}",
                Wrap("New ticket", staffBody, manageUrl, "Open in admin"));
        }

        // WhatsApp: template ticket_created  ->  {{1}} name, {{2}} token, {{3}} product, {{4}} link
        if (whatsAppTo != null)
            await _whatsApp.SendTemplateAsync(whatsAppTo, _wa.Templates.TicketCreated,
                new[] { Clean(customerName, 60), t.Token, Clean(t.Product?.Name, 60), trackUrl });

        await AlertSupportAsync(t, customerName, $"New {t.Priority} ticket: {t.Subject}", manageUrl);
    }

    public async Task TicketUpdatedAsync(Ticket t, string customerEmail, string? reply,
        bool statusChanged, string detailsUrl, string? whatsAppTo = null)
    {
        var sb = new StringBuilder();
        if (statusChanged)
            sb.Append($"<p>The status of your ticket is now <b>{E(t.Status.Label())}</b>.</p>");
        if (!string.IsNullOrWhiteSpace(reply))
            sb.Append("<p>Our team replied:</p>" +
                      $"<blockquote style=\"margin:0;padding:8px 14px;border-left:3px solid #0e5e5a;background:#f3f6f7\">{Multiline(reply)}</blockquote>");
        sb.Append(Facts(t));

        await _email.SendAsync(customerEmail, $"[{t.Token}] Update on your ticket",
            Wrap("Your ticket was updated", sb.ToString(), detailsUrl, "View the conversation"));

        // WhatsApp: template ticket_updated  ->  {{1}} name, {{2}} token, {{3}} status, {{4}} message, {{5}} link
        if (whatsAppTo != null)
            await _whatsApp.SendTemplateAsync(whatsAppTo, _wa.Templates.TicketUpdated, new[]
            {
                Clean(t.Customer?.FullName ?? "there", 60),
                t.Token,
                t.Status.Label(),
                string.IsNullOrWhiteSpace(reply) ? "No new message." : Clean(reply, 300),
                detailsUrl
            });
    }

    public async Task CustomerRepliedAsync(Ticket t, string customerName, string body, string manageUrl)
    {
        if (!string.IsNullOrWhiteSpace(_settings.SupportInbox))
        {
            var html = $"<p>{E(customerName)} replied:</p>" +
                       $"<blockquote style=\"margin:0;padding:8px 14px;border-left:3px solid #2b5fd9;background:#f3f6f7\">{Multiline(body)}</blockquote>" +
                       Facts(t);

            await _email.SendAsync(_settings.SupportInbox, $"[{t.Token}] Customer reply: {t.Subject}",
                Wrap("Customer reply", html, manageUrl, "Open in admin"));
        }

        await AlertSupportAsync(t, customerName, $"Customer reply: {body}", manageUrl);
    }

    // ---- WhatsApp alert to the support team ---------------------------

    // template ticket_support_alert  ->  {{1}} token, {{2}} product, {{3}} customer, {{4}} summary, {{5}} link
    private async Task AlertSupportAsync(Ticket t, string customerName, string summary, string manageUrl)
    {
        var to = PhoneNumberHelper.Normalize(_wa.SupportNumber, _wa.DefaultCountryCode);
        if (to == null) return;

        await _whatsApp.SendTemplateAsync(to, _wa.Templates.SupportAlert, new[]
        {
            t.Token, Clean(t.Product?.Name, 60), Clean(customerName, 60), Clean(summary, 200), manageUrl
        });
    }

    // ---- helpers -------------------------------------------------------

    /// <summary>WhatsApp template parameters cannot contain new lines, tabs or runs of spaces, and cannot be empty.</summary>
    private static string Clean(string? text, int max)
    {
        var s = Regex.Replace(text ?? string.Empty, @"\s+", " ").Trim();
        if (s.Length > max) s = s[..(max - 3)] + "...";
        return s.Length == 0 ? "-" : s;
    }

    private static string E(string? s) => WebUtility.HtmlEncode(s ?? string.Empty);

    private static string Multiline(string s) => E(s).Replace("\r\n", "\n").Replace("\n", "<br>");

    private static string Facts(Ticket t) =>
        "<table style=\"border-collapse:collapse;margin:12px 0;font-size:14px\">" +
        Row("Token", t.Token) +
        Row("Product", t.Product?.Name ?? "") +
        Row("Subject", t.Subject) +
        Row("Priority", t.Priority.ToString()) +
        Row("Status", t.Status.Label()) +
        "</table>";

    private static string Row(string k, string v) =>
        $"<tr><td style=\"padding:3px 16px 3px 0;color:#6b7785\">{k}</td><td style=\"padding:3px 0\">{E(v)}</td></tr>";

    private static string Wrap(string title, string inner, string linkUrl, string linkText) =>
        "<div style=\"font-family:Segoe UI,Arial,sans-serif;color:#16202a;max-width:560px;margin:auto\">" +
        $"<h2 style=\"margin:0 0 12px\">{E(title)}</h2>{inner}" +
        $"<p style=\"margin:20px 0\"><a href=\"{WebUtility.HtmlEncode(linkUrl)}\" " +
        "style=\"background:#0e5e5a;color:#fff;padding:10px 16px;border-radius:6px;text-decoration:none;display:inline-block\">" +
        $"{E(linkText)}</a></p>" +
        "<p style=\"color:#6b7785;font-size:12px\">This message was sent by the Support Desk.</p></div>";
}
