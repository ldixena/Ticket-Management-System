namespace SupportDesk.Services;

public class SmtpSettings
{
    public string Host { get; set; } = string.Empty;
    public int Port { get; set; } = 587;
    public bool UseStartTls { get; set; } = true;
    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string FromAddress { get; set; } = "support@example.com";
    public string FromName { get; set; } = "Support Desk";

    /// <summary>Internal mailbox that is told about new tickets and customer replies.</summary>
    public string SupportInbox { get; set; } = string.Empty;
}
