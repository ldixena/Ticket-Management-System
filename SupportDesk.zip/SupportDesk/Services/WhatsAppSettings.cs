namespace SupportDesk.Services;

public class WhatsAppSettings
{
    /// <summary>Master switch. When false (or the token / phone number id are empty) nothing is sent and nothing breaks.</summary>
    public bool Enabled { get; set; }

    /// <summary>Permanent token of a System User in Meta Business Manager.</summary>
    public string AccessToken { get; set; } = string.Empty;

    /// <summary>The "Phone number ID" of your WhatsApp Business number (not the phone number itself).</summary>
    public string PhoneNumberId { get; set; } = string.Empty;

    public string ApiVersion { get; set; } = "v21.0";
    public string TemplateLanguage { get; set; } = "en";

    /// <summary>Prefixed to numbers typed without a country code (91 = India).</summary>
    public string DefaultCountryCode { get; set; } = string.Empty;

    /// <summary>Support team's WhatsApp number (E.164). Receives new-ticket and customer-reply alerts.</summary>
    public string SupportNumber { get; set; } = string.Empty;

    public WhatsAppTemplates Templates { get; set; } = new();
}

public class WhatsAppTemplates
{
    public string TicketCreated { get; set; } = "ticket_created";
    public string TicketUpdated { get; set; } = "ticket_updated";
    public string SupportAlert { get; set; } = "ticket_support_alert";
}
