using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace SupportDesk.Controllers;

/// <summary>Page shells only. All data and actions go through /api/auth (see Controllers/Api).</summary>
public class AccountController : Controller
{
    public IActionResult Login() => View();
    public IActionResult Register() => View();

    [Authorize] public IActionResult Profile() => View();
    [Authorize] public IActionResult ChangePassword() => View();

    public IActionResult AccessDenied() => View();
}
