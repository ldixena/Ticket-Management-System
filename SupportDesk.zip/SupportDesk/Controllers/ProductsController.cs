using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SupportDesk.Models;

namespace SupportDesk.Controllers;

/// <summary>Page shells only. Data comes from /api/admin/products.</summary>
[Authorize(Roles = Roles.Admin)]
public class ProductsController : Controller
{
    public IActionResult Index() => View();
    public IActionResult Create() => View("Form", 0);
    public IActionResult Edit(int id) => View("Form", id);
}
