using Microsoft.AspNetCore.Mvc;

namespace SupportDesk.Controllers;

/// <summary>Page shell. The lookup itself is GET /api/track/{token}.</summary>
public class TrackController : Controller
{
    [HttpGet("track")]
    public IActionResult Index() => View();
}
