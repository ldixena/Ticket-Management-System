using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace SupportDesk.Controllers;

/// <summary>Page shells only. Data comes from /api/tickets and /api/products.</summary>
[Authorize]
public class TicketsController : Controller
{
    public IActionResult Index() => View();
    public IActionResult Create() => View();
    public IActionResult Details(int id) => View(id);
}
