using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SupportDesk.Models;

namespace SupportDesk.Controllers;

/// <summary>Page shells only. Data comes from /api/admin.</summary>
[Authorize(Roles = Roles.Admin)]
public class AdminController : Controller
{
    public IActionResult Index() => View();
    public IActionResult Manage(int id) => View(id);
    public IActionResult Reports() => View();
    public IActionResult Users() => View();
    public IActionResult LoginHistory() => View();
}
