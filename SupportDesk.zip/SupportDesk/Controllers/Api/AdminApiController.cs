using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SupportDesk.Api;
using SupportDesk.Data;
using SupportDesk.Models;
using SupportDesk.Services;

namespace SupportDesk.Controllers.Api;

[Route("api/admin")]
[Authorize(Roles = Roles.Admin, AuthenticationSchemes = ApiAuth.Schemes)]
public class AdminApiController : ApiBase
{
    private const int PageSize = 10;

    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _users;
    private readonly TicketNotifier _notifier;
    private readonly IAttachmentService _attachments;

    public AdminApiController(ApplicationDbContext db, UserManager<ApplicationUser> users,
        TicketNotifier notifier, IAttachmentService attachments)
    {
        _db = db;
        _users = users;
        _notifier = notifier;
        _attachments = attachments;
    }

    /// <summary>Status totals and per-product counts for the dashboard.</summary>
    [HttpGet("dashboard")]
    public async Task<ActionResult<DashboardDto>> Dashboard()
    {
        var counts = await _db.Tickets.AsNoTracking()
            .GroupBy(t => t.Status)
            .Select(g => new { Status = g.Key, Count = g.Count() })
            .ToListAsync();

        int CountOf(TicketStatus s) => counts.FirstOrDefault(c => c.Status == s)?.Count ?? 0;
        var open = CountOf(TicketStatus.Open);
        var inProgress = CountOf(TicketStatus.InProgress);
        var closed = CountOf(TicketStatus.Closed);
        var today = DateTime.UtcNow.Date;

        return new DashboardDto(
            open + inProgress + closed, open, inProgress, closed,
            await _db.Tickets.CountAsync(t => t.Priority == TicketPriority.Urgent && t.Status != TicketStatus.Closed),
            await _db.Tickets.CountAsync(t => t.CreatedAt >= today),
            await _db.Products.AsNoTracking()
                .Select(p => new ProductStatDto(
                    p.Name,
                    p.Tickets.Count,
                    p.Tickets.Count(t => t.Status != TicketStatus.Closed)))
                .OrderByDescending(p => p.Total).ThenBy(p => p.Name)
                .Take(6)
                .ToListAsync());
    }

    /// <summary>Searchable, paged ticket list. Unresolved first, most urgent first.</summary>
    [HttpGet("tickets")]
    public async Task<ActionResult<PagedResult<TicketSummaryDto>>> Tickets(string? q, TicketStatus? status, int page = 1)
    {
        var query = _db.Tickets.AsNoTracking()
            .Include(t => t.Product)
            .Include(t => t.Customer)
            .AsQueryable();

        if (status.HasValue)
            query = query.Where(t => t.Status == status.Value);

        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim();
            query = query.Where(t =>
                t.Token.Contains(term) ||
                t.Subject.Contains(term) ||
                t.Product!.Name.Contains(term) ||
                t.Customer!.FullName.Contains(term) ||
                t.Customer!.CompanyName!.Contains(term) ||
                t.Customer!.Email!.Contains(term));
        }

        var total = await query.CountAsync();
        var totalPages = Math.Max(1, (int)Math.Ceiling(total / (double)PageSize));
        page = Math.Clamp(page, 1, totalPages);

        var items = await query
            .OrderBy(t => t.Status == TicketStatus.Closed)
            .ThenByDescending(t => t.Priority)
            .ThenByDescending(t => t.UpdatedAt)
            .Skip((page - 1) * PageSize)
            .Take(PageSize)
            .ToListAsync();

        return new PagedResult<TicketSummaryDto>(
            items.Select(t => ApiMapping.Summary(t, true)).ToList(), page, totalPages, total);
    }

    [HttpGet("tickets/{id:int}")]
    public async Task<ActionResult<TicketDetailDto>> GetTicket(int id)
    {
        var ticket = await LoadAsync(id, track: false);
        if (ticket == null) return NotFound();
        return ApiMapping.Detail(ticket, forAdmin: true);
    }

    /// <summary>Changes status and/or replies. multipart/form-data: status, reply, files[]. Emails the customer.</summary>
    [HttpPost("tickets/{id:int}/update"), Consumes("multipart/form-data")]
    public async Task<ActionResult<TicketDetailDto>> Update(int id, [FromForm] UpdateTicketRequest req)
    {
        var ticket = await LoadAsync(id, track: true);
        if (ticket == null) return NotFound();

        var reply = string.IsNullOrWhiteSpace(req.Reply) ? null : req.Reply.Trim();

        var fileError = _attachments.Validate(req.Files);
        if (fileError != null)
            ModelState.AddModelError(nameof(req.Files), fileError);

        var hasFiles = req.Files != null && req.Files.Any(f => f.Length > 0);
        if (reply == null && hasFiles) reply = "See the attached file(s).";

        var statusChanged = ticket.Status != req.Status;
        if (!statusChanged && reply == null)
            ModelState.AddModelError(nameof(req.Reply), "Nothing to save. Change the status or write a reply.");

        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var admin = (await _users.GetUserAsync(User))!;

        TicketMessage? message = null;
        if (reply != null)
        {
            message = new TicketMessage { TicketId = ticket.Id, AuthorId = admin.Id, IsStaff = true, Body = reply };
            _db.TicketMessages.Add(message);
        }

        if (statusChanged)
        {
            ticket.Status = req.Status;
            ticket.ClosedAt = req.Status == TicketStatus.Closed ? DateTime.UtcNow : null;
        }
        ticket.UpdatedAt = DateTime.UtcNow;
        await _db.SaveChangesAsync();

        if (hasFiles && message != null)
        {
            try
            {
                await _attachments.SaveAsync(req.Files, ticket.Id, message.Id, admin.Id);
            }
            catch (IOException)
            {
                ModelState.AddModelError(nameof(req.Files), "The reply was sent, but the attachments could not be saved.");
            }
        }

        await _notifier.TicketUpdatedAsync(ticket, ticket.Customer!.Email!, reply, statusChanged,
            Url.Action("Details", "Tickets", new { id = ticket.Id }, Request.Scheme)!,
            ticket.Customer.WhatsAppTarget());

        var fresh = await LoadAsync(id, track: false);
        return ApiMapping.Detail(fresh!, forAdmin: true);
    }

    private async Task<Ticket?> LoadAsync(int id, bool track)
    {
        var query = _db.Tickets
            .Include(t => t.Product)
            .Include(t => t.Customer)
            .Include(t => t.Messages.OrderBy(m => m.CreatedAt)).ThenInclude(m => m.Author)
            .Include(t => t.Attachments)
            .Where(t => t.Id == id)
            .AsSplitQuery();
        return track ? await query.FirstOrDefaultAsync() : await query.AsNoTracking().FirstOrDefaultAsync();
    }
}
