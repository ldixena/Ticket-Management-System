using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SupportDesk.Api;
using SupportDesk.Data;

namespace SupportDesk.Controllers.Api;

[Route("api/products")]
public class ProductsApiController : ApiBase
{
    private readonly ApplicationDbContext _db;

    public ProductsApiController(ApplicationDbContext db) => _db = db;

    /// <summary>Active products a customer can raise a ticket against.</summary>
    [HttpGet]
    public async Task<ActionResult<List<ProductOption>>> Active() =>
        await _db.Products.AsNoTracking()
            .Where(p => p.IsActive)
            .OrderBy(p => p.Name)
            .Select(p => new ProductOption(p.Id, p.Name, p.Description))
            .ToListAsync();
}
