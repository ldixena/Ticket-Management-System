using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SupportDesk.Api;
using SupportDesk.Data;
using SupportDesk.Models;

namespace SupportDesk.Controllers.Api;

[Route("api/admin/products")]
[Authorize(Roles = Roles.Admin, AuthenticationSchemes = ApiAuth.Schemes)]
public class AdminProductsApiController : ApiBase
{
    private readonly ApplicationDbContext _db;

    public AdminProductsApiController(ApplicationDbContext db) => _db = db;

    [HttpGet]
    public async Task<ActionResult<List<ProductDto>>> List() =>
        await _db.Products.AsNoTracking()
            .OrderByDescending(p => p.IsActive).ThenBy(p => p.Name)
            .Select(p => new ProductDto(p.Id, p.Name, p.Description, p.IsActive, p.Tickets.Count))
            .ToListAsync();

    [HttpGet("{id:int}")]
    public async Task<ActionResult<ProductDto>> GetOne(int id)
    {
        var p = await _db.Products.AsNoTracking()
            .Where(x => x.Id == id)
            .Select(x => new ProductDto(x.Id, x.Name, x.Description, x.IsActive, x.Tickets.Count))
            .FirstOrDefaultAsync();
        if (p == null) return NotFound();
        return p;
    }

    [HttpPost]
    public async Task<ActionResult<ProductDto>> Create(ProductRequest req)
    {
        var name = req.Name.Trim();
        if (await _db.Products.AnyAsync(p => p.Name == name))
            ModelState.AddModelError(nameof(req.Name), "A product with this name already exists.");
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var product = new Product
        {
            Name = name,
            Description = string.IsNullOrWhiteSpace(req.Description) ? null : req.Description.Trim(),
            IsActive = req.IsActive
        };
        _db.Products.Add(product);
        await _db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetOne), new { id = product.Id },
            new ProductDto(product.Id, product.Name, product.Description, product.IsActive, 0));
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<ProductDto>> Update(int id, ProductRequest req)
    {
        var product = await _db.Products.FirstOrDefaultAsync(p => p.Id == id);
        if (product == null) return NotFound();

        var name = req.Name.Trim();
        if (await _db.Products.AnyAsync(p => p.Id != id && p.Name == name))
            ModelState.AddModelError(nameof(req.Name), "A product with this name already exists.");
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        product.Name = name;
        product.Description = string.IsNullOrWhiteSpace(req.Description) ? null : req.Description.Trim();
        product.IsActive = req.IsActive;
        await _db.SaveChangesAsync();

        var count = await _db.Tickets.CountAsync(t => t.ProductId == id);
        return new ProductDto(product.Id, product.Name, product.Description, product.IsActive, count);
    }

    /// <summary>Activate or deactivate. Products are never deleted so old tickets keep their product.</summary>
    [HttpPost("{id:int}/toggle")]
    public async Task<ActionResult<ProductDto>> Toggle(int id)
    {
        var product = await _db.Products.FirstOrDefaultAsync(p => p.Id == id);
        if (product == null) return NotFound();

        product.IsActive = !product.IsActive;
        await _db.SaveChangesAsync();

        var count = await _db.Tickets.CountAsync(t => t.ProductId == id);
        return new ProductDto(product.Id, product.Name, product.Description, product.IsActive, count);
    }
}
