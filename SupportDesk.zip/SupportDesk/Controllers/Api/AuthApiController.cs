using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.IdentityModel.Tokens;
using SupportDesk.Api;
using SupportDesk.Data;
using SupportDesk.Models;
using SupportDesk.Services;

namespace SupportDesk.Controllers.Api;

[Route("api/auth")]
public class AuthApiController : ApiBase
{
    private const string DisabledMessage = "This account is disabled. Contact the support team.";

    private readonly UserManager<ApplicationUser> _users;
    private readonly SignInManager<ApplicationUser> _signIn;
    private readonly WhatsAppSettings _whatsApp;
    private readonly JwtSettings _jwt;
    private readonly ILoginHistoryService _history;
    private readonly ApplicationDbContext _db;

    public AuthApiController(UserManager<ApplicationUser> users, SignInManager<ApplicationUser> signIn,
        IOptions<WhatsAppSettings> whatsApp, JwtSettings jwt, ILoginHistoryService history, ApplicationDbContext db)
    {
        _users = users;
        _signIn = signIn;
        _whatsApp = whatsApp.Value;
        _jwt = jwt;
        _history = history;
        _db = db;
    }

    /// <summary>Creates a customer account and signs the browser in (cookie).</summary>
    [HttpPost("register"), AllowAnonymous]
    public async Task<ActionResult<UserDto>> Register(RegisterRequest req)
    {
        var phone = ValidatePhone(req.PhoneNumber, req.WhatsAppOptIn);
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var user = new ApplicationUser
        {
            UserName = req.Email,
            Email = req.Email,
            FullName = req.FullName.Trim(),
            CompanyName = Blank(req.CompanyName),
            Address = Blank(req.Address),
            PhoneNumber = phone,
            WhatsAppOptIn = req.WhatsAppOptIn && phone != null
        };

        var result = await _users.CreateAsync(user, req.Password);
        if (!result.Succeeded)
        {
            AddIdentityErrors(result, "Password");
            return ValidationProblem(ModelState);
        }

        await _users.AddToRoleAsync(user, Roles.Customer);
        await _signIn.SignInAsync(user, isPersistent: false);
        await _history.RecordAsync(HttpContext, user, user.Email, LoginEventType.SignedIn, "Web", "Account created");
        return await ToDto(user);
    }

    /// <summary>Signs the browser in (cookie). Used by the website's pages.</summary>
    [HttpPost("login"), AllowAnonymous]
    public async Task<ActionResult<UserDto>> Login(LoginRequest req)
    {
        var user = await _users.FindByEmailAsync(req.Email);

        if (user is { IsDisabled: true })
        {
            await _history.RecordAsync(HttpContext, user, req.Email, LoginEventType.Failed, "Web", "Account disabled");
            ModelState.AddModelError(string.Empty, DisabledMessage);
            return ValidationProblem(ModelState);
        }

        var result = await _signIn.PasswordSignInAsync(req.Email, req.Password, req.RememberMe, lockoutOnFailure: true);
        if (!result.Succeeded)
        {
            await _history.RecordAsync(HttpContext, user, req.Email,
                result.IsLockedOut ? LoginEventType.LockedOut : LoginEventType.Failed, "Web",
                result.IsLockedOut ? "Too many failed attempts" : "Wrong password or unknown email");

            ModelState.AddModelError(string.Empty, result.IsLockedOut
                ? "Too many attempts. Try again in a few minutes."
                : "Email or password is incorrect.");
            return ValidationProblem(ModelState);
        }

        await _history.RecordAsync(HttpContext, user, req.Email, LoginEventType.SignedIn, "Web");
        return await ToDto(user!);
    }

    /// <summary>Returns a JWT for API clients (mobile apps, scripts). Send it as "Authorization: Bearer ...".</summary>
    [HttpPost("token"), AllowAnonymous]
    public async Task<ActionResult<TokenResponse>> Token(LoginRequest req)
    {
        var user = await _users.FindByEmailAsync(req.Email);

        if (user is { IsDisabled: true })
        {
            await _history.RecordAsync(HttpContext, user, req.Email, LoginEventType.Failed, "API", "Account disabled");
            return Unauthorized(new ProblemDetails { Status = 401, Title = DisabledMessage });
        }

        var check = user == null
            ? Microsoft.AspNetCore.Identity.SignInResult.Failed
            : await _signIn.CheckPasswordSignInAsync(user, req.Password, lockoutOnFailure: true);

        if (user == null || !check.Succeeded)
        {
            await _history.RecordAsync(HttpContext, user, req.Email,
                check.IsLockedOut ? LoginEventType.LockedOut : LoginEventType.Failed, "API",
                check.IsLockedOut ? "Too many failed attempts" : "Wrong password or unknown email");

            return Unauthorized(new ProblemDetails
            {
                Status = 401,
                Title = check.IsLockedOut ? "Too many attempts. Try again in a few minutes." : "Email or password is incorrect."
            });
        }

        var roles = await _users.GetRolesAsync(user);
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id),
            new(ClaimTypes.Name, user.Email ?? user.UserName ?? ""),
            new(ClaimTypes.Email, user.Email ?? "")
        };
        claims.AddRange(roles.Select(r => new Claim(ClaimTypes.Role, r)));

        var expires = DateTime.UtcNow.AddMinutes(_jwt.ExpiryMinutes);
        var jwt = new JsonWebTokenHandler().CreateToken(new SecurityTokenDescriptor
        {
            Subject = new ClaimsIdentity(claims),
            Issuer = _jwt.Issuer,
            Audience = _jwt.Audience,
            Expires = expires,
            SigningCredentials = new SigningCredentials(
                new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwt.Key)), SecurityAlgorithms.HmacSha256)
        });

        await _history.RecordAsync(HttpContext, user, req.Email, LoginEventType.SignedIn, "API");
        return new TokenResponse(jwt, "Bearer", expires, await ToDto(user));
    }

    [HttpPost("logout"), AllowAnonymous]
    public async Task<IActionResult> Logout()
    {
        var user = await _users.GetUserAsync(User);
        await _signIn.SignOutAsync();
        if (user != null)
            await _history.RecordAsync(HttpContext, user, user.Email ?? "", LoginEventType.SignedOut, "Web");
        return NoContent();
    }

    [HttpGet("me")]
    public async Task<ActionResult<UserDto>> Me()
    {
        var user = await _users.GetUserAsync(User);
        if (user == null) return Unauthorized();
        return await ToDto(user);
    }

    /// <summary>The signed-in user's own sign-in history, newest first (includes failed attempts on their account).</summary>
    [HttpGet("login-history")]
    public async Task<ActionResult<PagedResult<LoginHistoryDto>>> MyHistory(int page = 1)
    {
        const int pageSize = 20;
        var userId = _users.GetUserId(User)!;
        var query = _db.LoginHistories.AsNoTracking().Where(h => h.UserId == userId);

        var total = await query.CountAsync();
        var totalPages = Math.Max(1, (int)Math.Ceiling(total / (double)pageSize));
        page = Math.Clamp(page, 1, totalPages);

        var rows = await query.OrderByDescending(h => h.CreatedAt).ThenByDescending(h => h.Id)
            .Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();

        return new PagedResult<LoginHistoryDto>(rows.Select(ApiMapping.History).ToList(), page, totalPages, total);
    }

    [HttpPut("profile")]
    public async Task<ActionResult<UserDto>> UpdateProfile(ProfileRequest req)
    {
        var user = await _users.GetUserAsync(User);
        if (user == null) return Unauthorized();

        var phone = ValidatePhone(req.PhoneNumber, req.WhatsAppOptIn);
        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        user.FullName = req.FullName.Trim();
        user.CompanyName = Blank(req.CompanyName);
        user.Address = Blank(req.Address);
        user.PhoneNumber = phone;
        user.WhatsAppOptIn = req.WhatsAppOptIn && phone != null;

        var result = await _users.UpdateAsync(user);
        if (!result.Succeeded)
        {
            AddIdentityErrors(result, "FullName");
            return ValidationProblem(ModelState);
        }

        await RefreshCookieAsync(user);
        return await ToDto(user);
    }

    [HttpPost("change-password")]
    public async Task<IActionResult> ChangePassword(ChangePasswordRequest req)
    {
        var user = await _users.GetUserAsync(User);
        if (user == null) return Unauthorized();

        if (req.CurrentPassword == req.NewPassword)
        {
            ModelState.AddModelError(nameof(req.NewPassword), "Choose a password different from the current one.");
            return ValidationProblem(ModelState);
        }

        var result = await _users.ChangePasswordAsync(user, req.CurrentPassword, req.NewPassword);
        if (!result.Succeeded)
        {
            AddIdentityErrors(result, "NewPassword");
            return ValidationProblem(ModelState);
        }

        await RefreshCookieAsync(user);
        return NoContent();
    }

    // ---- helpers ----

    private static string? Blank(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

    private async Task RefreshCookieAsync(ApplicationUser user)
    {
        // Only browser (cookie) sessions need a fresh cookie; bearer clients just keep their token.
        if (User.Identity?.AuthenticationType == IdentityConstants.ApplicationScheme)
            await _signIn.RefreshSignInAsync(user);
    }

    private async Task<UserDto> ToDto(ApplicationUser user) => new(
        user.Id, user.FullName, user.Email ?? "", user.CompanyName, user.Address, user.PhoneNumber,
        user.WhatsAppOptIn, (await _users.GetRolesAsync(user)).ToArray());

    private string? ValidatePhone(string? input, bool optIn)
    {
        string? e164 = null;
        if (!string.IsNullOrWhiteSpace(input))
        {
            var digits = PhoneNumberHelper.Normalize(input, _whatsApp.DefaultCountryCode);
            if (digits == null)
                ModelState.AddModelError("PhoneNumber", "Enter a valid number with country code, for example +91 98765 43210.");
            else
                e164 = "+" + digits;
        }

        if (optIn && string.IsNullOrWhiteSpace(input))
            ModelState.AddModelError("PhoneNumber", "Add your WhatsApp number to get WhatsApp updates.");

        return e164;
    }

    private void AddIdentityErrors(IdentityResult result, string passwordField)
    {
        foreach (var e in result.Errors)
        {
            var key = e.Code switch
            {
                "PasswordMismatch" => "CurrentPassword",
                var c when c.StartsWith("Password") => passwordField,
                var c when c.Contains("Email") || c.Contains("UserName") => "Email",
                _ => string.Empty
            };
            ModelState.AddModelError(key, e.Description);
        }
    }
}
