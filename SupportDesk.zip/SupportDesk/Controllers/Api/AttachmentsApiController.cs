using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SupportDesk.Api;
using SupportDesk.Data;
using SupportDesk.Models;
using SupportDesk.Services;

namespace SupportDesk.Controllers.Api;

/// <summary>Files live outside wwwroot and are only served here, after an ownership check.</summary>
[Route("api/attachments")]
public class AttachmentsApiController : ApiBase
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _users;
    private readonly IAttachmentService _attachments;

    public AttachmentsApiController(ApplicationDbContext db, UserManager<ApplicationUser> users, IAttachmentService attachments)
    {
        _db = db;
        _users = users;
        _attachments = attachments;
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Download(int id)
    {
        var file = await _db.TicketAttachments.AsNoTracking()
            .Include(a => a.Ticket)
            .FirstOrDefaultAsync(a => a.Id == id);
        if (file == null) return NotFound();

        // Customers can only open files on their own tickets; admins can open any.
        if (!User.IsInRole(Roles.Admin) && file.Ticket!.CustomerId != _users.GetUserId(User))
            return NotFound();

        var stream = _attachments.Open(file);
        if (stream == null) return NotFound();

        Response.Headers["X-Content-Type-Options"] = "nosniff";

        if (_attachments.IsInline(file.ContentType))
        {
            Response.Headers["Content-Disposition"] =
                new System.Net.Mime.ContentDisposition { Inline = true, FileName = file.OriginalFileName }.ToString();
            return File(stream, file.ContentType);
        }

        return File(stream, "application/octet-stream", file.OriginalFileName);
    }
}
