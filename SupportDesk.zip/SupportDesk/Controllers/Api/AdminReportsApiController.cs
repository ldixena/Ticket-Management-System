using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SupportDesk.Api;
using SupportDesk.Data;
using SupportDesk.Models;

namespace SupportDesk.Controllers.Api;

/// <summary>Ticket report: filter by status (open, in progress, closed or all), dates, product, priority and text.</summary>
[Route("api/admin/reports")]
[Authorize(Roles = Roles.Admin, AuthenticationSchemes = ApiAuth.Schemes)]
public class AdminReportsApiController : ApiBase
{
    private const int PageSize = 25;
    private const int CsvLimit = 50_000;

    private readonly ApplicationDbContext _db;

    public AdminReportsApiController(ApplicationDbContext db) => _db = db;

    /// <summary>Counts, priority breakdown and a page of matching tickets. Dates are UTC and filter on the created date.</summary>
    [HttpGet("tickets")]
    public async Task<ActionResult<TicketReportDto>> Tickets([FromQuery] ReportFilter f)
    {
        var baseQuery = Base(f);

        // Totals ignore the status filter so you always see the full open / in progress / closed split.
        var counts = await baseQuery.GroupBy(t => t.Status)
            .Select(g => new { Status = g.Key, Count = g.Count() })
            .ToListAsync();
        int CountOf(TicketStatus s) => counts.FirstOrDefault(c => c.Status == s)?.Count ?? 0;

        var filtered = f.Status.HasValue ? baseQuery.Where(t => t.Status == f.Status.Value) : baseQuery;

        var closed = await filtered.Where(t => t.ClosedAt != null)
            .Select(t => new { t.CreatedAt, ClosedAt = t.ClosedAt!.Value })
            .Take(20_000)
            .ToListAsync();
        double? avgHours = closed.Count == 0 ? null : Math.Round(closed.Average(x => (x.ClosedAt - x.CreatedAt).TotalHours), 1);

        var matching = await filtered.CountAsync();
        var byPriority = await filtered.GroupBy(t => t.Priority)
            .Select(g => new { Priority = g.Key, Count = g.Count() })
            .ToListAsync();

        var totalPages = Math.Max(1, (int)Math.Ceiling(matching / (double)PageSize));
        var page = Math.Clamp(f.Page, 1, totalPages);

        var rows = await filtered
            .Include(t => t.Product).Include(t => t.Customer)
            .OrderByDescending(t => t.CreatedAt).ThenByDescending(t => t.Id)
            .Skip((page - 1) * PageSize).Take(PageSize)
            .ToListAsync();

        var summary = new ReportSummaryDto(
            CountOf(TicketStatus.Open) + CountOf(TicketStatus.InProgress) + CountOf(TicketStatus.Closed),
            CountOf(TicketStatus.Open), CountOf(TicketStatus.InProgress), CountOf(TicketStatus.Closed),
            matching, avgHours);

        return new TicketReportDto(
            summary,
            byPriority.OrderByDescending(x => x.Priority).Select(x => new ReportPriorityDto(x.Priority.ToString(), x.Count)).ToList(),
            new PagedResult<ReportRowDto>(rows.Select(Row).ToList(), page, totalPages, matching));
    }

    /// <summary>The same report as a CSV download (opens in Excel). Up to 50,000 rows.</summary>
    [HttpGet("tickets.csv")]
    public async Task<IActionResult> TicketsCsv([FromQuery] ReportFilter f)
    {
        var filtered = Base(f);
        if (f.Status.HasValue) filtered = filtered.Where(t => t.Status == f.Status.Value);

        var rows = await filtered
            .Include(t => t.Product).Include(t => t.Customer)
            .OrderByDescending(t => t.CreatedAt).ThenByDescending(t => t.Id)
            .Take(CsvLimit)
            .ToListAsync();

        var sb = new StringBuilder();
        sb.AppendLine("Token,Subject,Product,Priority,Status,Customer,Company,Email,Created (UTC),Updated (UTC),Closed (UTC)");
        foreach (var t in rows.Select(Row))
        {
            sb.AppendLine(string.Join(",", new[]
            {
                Csv(t.Token), Csv(t.Subject), Csv(t.Product), Csv(t.Priority), Csv(t.Status), Csv(t.Customer),
                Csv(t.Company), Csv(t.Email), Csv(Iso(t.CreatedAt)), Csv(Iso(t.UpdatedAt)), Csv(t.ClosedAt.HasValue ? Iso(t.ClosedAt.Value) : "")
            }));
        }

        // The byte-order mark makes Excel read accents and non-Latin names correctly.
        var bytes = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
        return File(bytes, "text/csv; charset=utf-8", $"tickets-{DateTime.UtcNow:yyyyMMdd-HHmm}.csv");
    }

    // ---- helpers ----

    private IQueryable<Ticket> Base(ReportFilter f)
    {
        var query = _db.Tickets.AsNoTracking().AsQueryable();

        if (f.From.HasValue)
        {
            var from = f.From.Value.ToDateTime(TimeOnly.MinValue, DateTimeKind.Utc);
            query = query.Where(t => t.CreatedAt >= from);
        }
        if (f.To.HasValue)
        {
            var toExclusive = f.To.Value.AddDays(1).ToDateTime(TimeOnly.MinValue, DateTimeKind.Utc);
            query = query.Where(t => t.CreatedAt < toExclusive);
        }
        if (f.ProductId.HasValue)
        {
            var productId = f.ProductId.Value;
            query = query.Where(t => t.ProductId == productId);
        }
        if (f.Priority.HasValue)
        {
            var priority = f.Priority.Value;
            query = query.Where(t => t.Priority == priority);
        }
        if (!string.IsNullOrWhiteSpace(f.Q))
        {
            var term = f.Q.Trim();
            query = query.Where(t =>
                t.Token.Contains(term) || t.Subject.Contains(term) ||
                t.Customer!.FullName.Contains(term) || t.Customer!.CompanyName!.Contains(term) ||
                t.Customer!.Email!.Contains(term));
        }
        return query;
    }

    private static ReportRowDto Row(Ticket t) => new(
        t.Id, t.Token, t.Subject, t.Product?.Name ?? "", t.Priority.ToString(), t.Status.ToString(),
        t.Customer?.FullName ?? "", t.Customer?.CompanyName, t.Customer?.Email ?? "",
        t.CreatedAt, t.UpdatedAt, t.ClosedAt);

    private static string Iso(DateTime d) => d.ToString("yyyy-MM-dd HH:mm");

    /// <summary>Quotes a CSV field and neutralises spreadsheet formulas (=, +, -, @) typed by customers.</summary>
    private static string Csv(string? value)
    {
        var v = value ?? "";
        if (v.Length > 0 && "=+-@\t\r".Contains(v[0])) v = "'" + v;
        if (v.IndexOfAny(new[] { ',', '"', '\n', '\r' }) >= 0) v = "\"" + v.Replace("\"", "\"\"") + "\"";
        return v;
    }
}
