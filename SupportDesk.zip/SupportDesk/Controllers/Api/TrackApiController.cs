using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using SupportDesk.Api;
using SupportDesk.Data;
using SupportDesk.Services;

namespace SupportDesk.Controllers.Api;

[Route("api/track")]
public class TrackApiController : ApiBase
{
    private readonly ApplicationDbContext _db;

    public TrackApiController(ApplicationDbContext db) => _db = db;

    /// <summary>Public status lookup by token. Never returns the description or conversation. Rate limited.</summary>
    [HttpGet("{token}"), AllowAnonymous, EnableRateLimiting("track")]
    public async Task<ActionResult<TrackDto>> Get(string token)
    {
        var normalized = TokenGenerator.Normalize(token);
        var t = await _db.Tickets.AsNoTracking()
            .Include(x => x.Product)
            .FirstOrDefaultAsync(x => x.Token == normalized);

        if (t == null) return NotFound(new ProblemDetails { Status = 404, Title = "No ticket matches that token." });

        return new TrackDto(t.Token, t.Subject, t.Product?.Name ?? "", t.Priority.ToString(),
            t.Status.ToString(), t.CreatedAt, t.UpdatedAt);
    }
}
