using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SupportDesk.Api;
using SupportDesk.Data;
using SupportDesk.Models;
using SupportDesk.Services;

namespace SupportDesk.Controllers.Api;

[Route("api/tickets")]
public class TicketsApiController : ApiBase
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _users;
    private readonly TicketNotifier _notifier;
    private readonly IAttachmentService _attachments;

    public TicketsApiController(ApplicationDbContext db, UserManager<ApplicationUser> users,
        TicketNotifier notifier, IAttachmentService attachments)
    {
        _db = db;
        _users = users;
        _notifier = notifier;
        _attachments = attachments;
    }

    /// <summary>The signed-in customer's tickets, newest activity first.</summary>
    [HttpGet]
    public async Task<ActionResult<List<TicketSummaryDto>>> List()
    {
        var userId = _users.GetUserId(User)!;
        var tickets = await _db.Tickets.AsNoTracking()
            .Include(t => t.Product)
            .Where(t => t.CustomerId == userId)
            .OrderByDescending(t => t.UpdatedAt)
            .ToListAsync();
        return tickets.Select(t => ApiMapping.Summary(t, false)).ToList();
    }

    /// <summary>Raises a ticket. multipart/form-data: productId, subject, description, priority, files[].</summary>
    [HttpPost, Consumes("multipart/form-data")]
    public async Task<ActionResult<TicketCreatedDto>> Create([FromForm] CreateTicketRequest req)
    {
        var product = await _db.Products.FirstOrDefaultAsync(p => p.Id == req.ProductId && p.IsActive);
        if (product == null)
            ModelState.AddModelError(nameof(req.ProductId), "Choose the product this is about.");

        var fileError = _attachments.Validate(req.Files);
        if (fileError != null)
            ModelState.AddModelError(nameof(req.Files), fileError);

        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var user = (await _users.GetUserAsync(User))!;
        var now = DateTime.UtcNow;

        var ticket = new Ticket
        {
            Token = await TokenGenerator.CreateUniqueAsync(_db),
            CustomerId = user.Id,
            ProductId = product!.Id,
            Subject = req.Subject.Trim(),
            Description = req.Description.Trim(),
            Priority = req.Priority,
            Status = TicketStatus.Open,
            CreatedAt = now,
            UpdatedAt = now
        };
        _db.Tickets.Add(ticket);
        await _db.SaveChangesAsync();

        string? warning = null;
        try
        {
            await _attachments.SaveAsync(req.Files, ticket.Id, null, user.Id);
        }
        catch (IOException)
        {
            warning = "Your ticket was created, but the attachments could not be saved. Attach them in a reply.";
        }

        ticket.Product = product;
        await _notifier.TicketCreatedAsync(
            ticket, user.Email!, user.FullName,
            trackUrl: Url.Action("Index", "Track", new { token = ticket.Token }, Request.Scheme)!,
            manageUrl: Url.Action("Manage", "Admin", new { id = ticket.Id }, Request.Scheme)!,
            whatsAppTo: user.WhatsAppTarget());

        return new TicketCreatedDto(ticket.Id, ticket.Token, warning);
    }

    /// <summary>Full conversation of one of the customer's own tickets.</summary>
    [HttpGet("{id:int}")]
    public async Task<ActionResult<TicketDetailDto>> Get(int id)
    {
        var ticket = await LoadOwnAsync(id, track: false);
        if (ticket == null) return NotFound();
        return ApiMapping.Detail(ticket, forAdmin: false);
    }

    /// <summary>Adds a reply. multipart/form-data: body, files[]. Returns the updated ticket.</summary>
    [HttpPost("{id:int}/replies"), Consumes("multipart/form-data")]
    public async Task<ActionResult<TicketDetailDto>> Reply(int id, [FromForm] ReplyRequest req)
    {
        var ticket = await LoadOwnAsync(id, track: true);
        if (ticket == null) return NotFound();

        if (ticket.Status == TicketStatus.Closed)
            ModelState.AddModelError(nameof(req.Body), "This ticket is closed. Raise a new ticket if you need more help.");

        var fileError = _attachments.Validate(req.Files);
        if (fileError != null)
            ModelState.AddModelError(nameof(req.Files), fileError);

        if (!ModelState.IsValid) return ValidationProblem(ModelState);

        var user = (await _users.GetUserAsync(User))!;
        var message = new TicketMessage
        {
            TicketId = ticket.Id,
            AuthorId = user.Id,
            IsStaff = false,
            Body = req.Body.Trim()
        };
        _db.TicketMessages.Add(message);
        ticket.UpdatedAt = DateTime.UtcNow;
        await _db.SaveChangesAsync();

        try
        {
            await _attachments.SaveAsync(req.Files, ticket.Id, message.Id, user.Id);
        }
        catch (IOException)
        {
            ModelState.AddModelError(nameof(req.Files), "Your reply was sent, but the attachments could not be saved.");
        }

        await _notifier.CustomerRepliedAsync(ticket, user.FullName, message.Body,
            Url.Action("Manage", "Admin", new { id = ticket.Id }, Request.Scheme)!);

        var fresh = await LoadOwnAsync(id, track: false);
        return ApiMapping.Detail(fresh!, forAdmin: false);
    }

    private async Task<Ticket?> LoadOwnAsync(int id, bool track)
    {
        var userId = _users.GetUserId(User)!;
        var query = _db.Tickets
            .Include(t => t.Product)
            .Include(t => t.Messages.OrderBy(m => m.CreatedAt)).ThenInclude(m => m.Author)
            .Include(t => t.Attachments)
            .Where(t => t.Id == id && t.CustomerId == userId)
            .AsSplitQuery();
        return track ? await query.FirstOrDefaultAsync() : await query.AsNoTracking().FirstOrDefaultAsync();
    }
}
