using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SupportDesk.Api;
using SupportDesk.Data;
using SupportDesk.Models;
using SupportDesk.Services;

namespace SupportDesk.Controllers.Api;

/// <summary>Manage who can sign in and who is an admin. Several admins are supported.</summary>
[Route("api/admin/users")]
[Authorize(Roles = Roles.Admin, AuthenticationSchemes = ApiAuth.Schemes)]
public class AdminUsersApiController : ApiBase
{
    private const int PageSize = 15;

    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _users;
    private readonly IEmailService _email;
    private readonly ILogger<AdminUsersApiController> _logger;

    public AdminUsersApiController(ApplicationDbContext db, UserManager<ApplicationUser> users,
        IEmailService email, ILogger<AdminUsersApiController> logger)
    {
        _db = db;
        _users = users;
        _email = email;
        _logger = logger;
    }

    [HttpGet]
    public async Task<ActionResult<PagedResult<AdminUserDto>>> List(string? q, string? role, int page = 1)
    {
        var adminRoleId = await _db.Roles.Where(r => r.Name == Roles.Admin).Select(r => r.Id).FirstOrDefaultAsync();
        var query = _db.Users.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim();
            query = query.Where(u => u.FullName.Contains(term) || u.Email!.Contains(term) || u.CompanyName!.Contains(term));
        }

        if (role == Roles.Admin)
            query = query.Where(u => _db.UserRoles.Any(ur => ur.UserId == u.Id && ur.RoleId == adminRoleId));
        else if (role == Roles.Customer)
            query = query.Where(u => !_db.UserRoles.Any(ur => ur.UserId == u.Id && ur.RoleId == adminRoleId));

        var total = await query.CountAsync();
        var totalPages = Math.Max(1, (int)Math.Ceiling(total / (double)PageSize));
        page = Math.Clamp(page, 1, totalPages);

        var rows = await query
            .OrderBy(u => u.FullName)
            .Skip((page - 1) * PageSize)
            .Take(PageSize)
            .Select(u => new
            {
                u.Id, u.FullName, u.Email, u.CompanyName, u.Address, u.PhoneNumber, u.IsDisabled, u.CreatedAt,
                LastSignIn = _db.LoginHistories
                    .Where(h => h.UserId == u.Id && h.EventType == LoginEventType.SignedIn)
                    .Max(h => (DateTime?)h.CreatedAt),
                Tickets = _db.Tickets.Count(t => t.CustomerId == u.Id)
            })
            .ToListAsync();

        var ids = rows.Select(r => r.Id).ToList();
        var roleRows = await _db.UserRoles
            .Where(ur => ids.Contains(ur.UserId))
            .Join(_db.Roles, ur => ur.RoleId, r => r.Id, (ur, r) => new { ur.UserId, Role = r.Name })
            .ToListAsync();

        var items = rows.Select(r => new AdminUserDto(
            r.Id, r.FullName, r.Email ?? "", r.CompanyName, r.Address, r.PhoneNumber,
            roleRows.Where(x => x.UserId == r.Id).Select(x => x.Role!).ToArray(),
            r.IsDisabled, r.CreatedAt, r.LastSignIn, r.Tickets)).ToList();

        return new PagedResult<AdminUserDto>(items, page, totalPages, total);
    }

    /// <summary>Creates another admin account directly.</summary>
    [HttpPost]
    public async Task<ActionResult<AdminUserDto>> CreateAdmin(CreateAdminRequest req)
    {
        var user = new ApplicationUser
        {
            UserName = req.Email,
            Email = req.Email,
            EmailConfirmed = true,
            FullName = req.FullName.Trim(),
            CompanyName = string.IsNullOrWhiteSpace(req.CompanyName) ? null : req.CompanyName.Trim()
        };

        var result = await _users.CreateAsync(user, req.Password);
        if (!result.Succeeded)
        {
            foreach (var e in result.Errors)
            {
                var key = e.Code.StartsWith("Password") ? "Password"
                    : e.Code.Contains("Email") || e.Code.Contains("UserName") ? "Email" : string.Empty;
                ModelState.AddModelError(key, e.Description);
            }
            return ValidationProblem(ModelState);
        }

        await _users.AddToRoleAsync(user, Roles.Admin);
        return await ToDto(user);
    }

    [HttpPost("{id}/make-admin")]
    public async Task<ActionResult<AdminUserDto>> MakeAdmin(string id)
    {
        var user = await _users.FindByIdAsync(id);
        if (user == null) return NotFound();
        if (user.IsDisabled) return Fail("Enable this account before making it an admin.");

        if (!await _users.IsInRoleAsync(user, Roles.Admin))
        {
            await _users.AddToRoleAsync(user, Roles.Admin);
            await _users.UpdateSecurityStampAsync(user); // they sign in again and get the new role
        }
        return await ToDto(user);
    }

    [HttpPost("{id}/remove-admin")]
    public async Task<ActionResult<AdminUserDto>> RemoveAdmin(string id)
    {
        var user = await _users.FindByIdAsync(id);
        if (user == null) return NotFound();

        var guard = await GuardAdminChangeAsync(user);
        if (guard != null) return Fail(guard);

        if (await _users.IsInRoleAsync(user, Roles.Admin))
        {
            await _users.RemoveFromRoleAsync(user, Roles.Admin);
            if (!await _users.IsInRoleAsync(user, Roles.Customer))
                await _users.AddToRoleAsync(user, Roles.Customer);
            await _users.UpdateSecurityStampAsync(user);
        }
        return await ToDto(user);
    }

    [HttpPost("{id}/disable")]
    public async Task<ActionResult<AdminUserDto>> Disable(string id)
    {
        var user = await _users.FindByIdAsync(id);
        if (user == null) return NotFound();

        var guard = await GuardAdminChangeAsync(user);
        if (guard != null) return Fail(guard);

        user.IsDisabled = true;
        await _users.UpdateAsync(user);
        await _users.UpdateSecurityStampAsync(user); // ends their current browser session
        return await ToDto(user);
    }

    [HttpPost("{id}/enable")]
    public async Task<ActionResult<AdminUserDto>> Enable(string id)
    {
        var user = await _users.FindByIdAsync(id);
        if (user == null) return NotFound();

        user.IsDisabled = false;
        await _users.UpdateAsync(user);
        await _users.ResetAccessFailedCountAsync(user);
        await _users.SetLockoutEndDateAsync(user, null);
        return await ToDto(user);
    }

    /// <summary>
    /// Sets a new password for someone else. Passwords are stored as one-way hashes and can never be read back,
    /// so a reset is the only way to give a user access again. Ends their current sessions and emails them.
    /// </summary>
    [HttpPost("{id}/reset-password")]
    public async Task<IActionResult> ResetPassword(string id, ResetPasswordRequest req)
    {
        var user = await _users.FindByIdAsync(id);
        if (user == null) return NotFound();

        if (user.Id == _users.GetUserId(User))
            return Fail("Use Change password from the account menu for your own account.");

        var token = await _users.GeneratePasswordResetTokenAsync(user);
        var result = await _users.ResetPasswordAsync(user, token, req.NewPassword);
        if (!result.Succeeded)
        {
            foreach (var e in result.Errors) ModelState.AddModelError("NewPassword", e.Description);
            return ValidationProblem(ModelState);
        }

        await _users.ResetAccessFailedCountAsync(user);
        await _users.SetLockoutEndDateAsync(user, null);
        await _users.UpdateSecurityStampAsync(user);

        _logger.LogWarning("Password for {UserId} was reset by admin {AdminId}", user.Id, _users.GetUserId(User));

        // The email never contains the password. The admin shares it directly.
        var loginUrl = Url.Action("Login", "Account", null, Request.Scheme) ?? "";
        await _email.SendAsync(user.Email!, "Your password was reset",
            "<div style=\"font-family:Segoe UI,Arial,sans-serif;color:#16202a;max-width:520px\">" +
            $"<p>Hi {System.Net.WebUtility.HtmlEncode(user.FullName)},</p>" +
            "<p>A support administrator reset your password. They will give you the new one directly. " +
            "You can change it any time from the account menu after you sign in.</p>" +
            "<p>If you did not expect this, contact the support team.</p>" +
            $"<p><a href=\"{System.Net.WebUtility.HtmlEncode(loginUrl)}\">Sign in</a></p></div>");

        return NoContent();
    }

    // ---- helpers ----

    /// <summary>Blocks changes that would lock everyone out: your own account, or the last active admin.</summary>
    private async Task<string?> GuardAdminChangeAsync(ApplicationUser target)
    {
        if (target.Id == _users.GetUserId(User))
            return "You can't do this to your own account. Ask another admin.";

        if (await _users.IsInRoleAsync(target, Roles.Admin))
        {
            var activeAdmins = (await _users.GetUsersInRoleAsync(Roles.Admin)).Count(u => !u.IsDisabled);
            if (activeAdmins <= 1)
                return "At least one active admin must remain.";
        }
        return null;
    }

    private ActionResult Fail(string message)
    {
        ModelState.AddModelError(string.Empty, message);
        return ValidationProblem(ModelState);
    }

    private async Task<AdminUserDto> ToDto(ApplicationUser u)
    {
        var last = await _db.LoginHistories
            .Where(h => h.UserId == u.Id && h.EventType == LoginEventType.SignedIn)
            .MaxAsync(h => (DateTime?)h.CreatedAt);
        var tickets = await _db.Tickets.CountAsync(t => t.CustomerId == u.Id);

        return new AdminUserDto(u.Id, u.FullName, u.Email ?? "", u.CompanyName, u.Address, u.PhoneNumber,
            (await _users.GetRolesAsync(u)).ToArray(), u.IsDisabled, u.CreatedAt, last, tickets);
    }
}
