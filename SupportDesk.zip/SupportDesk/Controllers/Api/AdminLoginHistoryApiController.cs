using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SupportDesk.Api;
using SupportDesk.Data;
using SupportDesk.Models;

namespace SupportDesk.Controllers.Api;

[Route("api/admin/login-history")]
[Authorize(Roles = Roles.Admin, AuthenticationSchemes = ApiAuth.Schemes)]
public class AdminLoginHistoryApiController : ApiBase
{
    private const int PageSize = 25;

    private readonly ApplicationDbContext _db;

    public AdminLoginHistoryApiController(ApplicationDbContext db) => _db = db;

    /// <summary>Everyone's sign-ins. Filters: q (email, name, IP), outcome (success|failed), userType (Admin|Customer|Unknown).</summary>
    [HttpGet]
    public async Task<ActionResult<PagedResult<LoginHistoryDto>>> List(string? q, string? outcome, string? userType, int page = 1)
    {
        var query = _db.LoginHistories.AsNoTracking().Include(h => h.User).AsQueryable();

        if (outcome == "success")
            query = query.Where(h => h.EventType == LoginEventType.SignedIn || h.EventType == LoginEventType.SignedOut);
        else if (outcome == "failed")
            query = query.Where(h => h.EventType == LoginEventType.Failed || h.EventType == LoginEventType.LockedOut);

        if (userType == "Admin" || userType == "Customer" || userType == "Unknown")
            query = query.Where(h => h.UserType == userType);

        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim();
            query = query.Where(h => h.Email.Contains(term) || h.IpAddress!.Contains(term) || h.User!.FullName.Contains(term));
        }

        var total = await query.CountAsync();
        var totalPages = Math.Max(1, (int)Math.Ceiling(total / (double)PageSize));
        page = Math.Clamp(page, 1, totalPages);

        var rows = await query.OrderByDescending(h => h.CreatedAt).ThenByDescending(h => h.Id)
            .Skip((page - 1) * PageSize).Take(PageSize).ToListAsync();

        return new PagedResult<LoginHistoryDto>(rows.Select(ApiMapping.History).ToList(), page, totalPages, total);
    }
}
