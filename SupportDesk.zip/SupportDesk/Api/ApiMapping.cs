using SupportDesk.Models;

namespace SupportDesk.Api;

public static class ApiMapping
{
    public static AttachmentDto Attachment(TicketAttachment a) => new(
        a.Id, a.OriginalFileName, a.ContentType, a.SizeBytes, $"/api/attachments/{a.Id}",
        a.ContentType.StartsWith("image/") && a.ContentType != "image/svg+xml");

    public static LoginHistoryDto History(LoginHistory h) => new(
        h.Id, h.User?.FullName, h.Email, h.UserType, h.EventType.ToString(), h.Reason, h.IpAddress,
        h.Device, h.Method, h.CreatedAt);

    public static TicketSummaryDto Summary(Ticket t, bool withCustomer) => new(
        t.Id, t.Token, t.Subject, t.Product?.Name ?? "", t.Priority.ToString(), t.Status.ToString(),
        withCustomer ? t.Customer?.FullName : null, withCustomer ? t.Customer?.CompanyName : null,
        t.CreatedAt, t.UpdatedAt);

    /// <summary>Needs Product, Messages (with Author) and Attachments loaded, plus Customer when forAdmin.</summary>
    public static TicketDetailDto Detail(Ticket t, bool forAdmin)
    {
        string Author(TicketMessage m) => m.IsStaff
            ? (forAdmin ? $"{m.Author?.FullName} (support)" : "Support team")
            : (forAdmin ? m.Author?.FullName ?? "Customer" : "You");

        return new TicketDetailDto(
            t.Id, t.Token, t.Subject, t.Description, t.Product?.Name ?? "",
            t.Priority.ToString(), t.Status.ToString(), t.CreatedAt, t.UpdatedAt, t.ClosedAt,
            forAdmin && t.Customer != null ? new CustomerDto(t.Customer.FullName, t.Customer.Email ?? "", t.Customer.CompanyName, t.Customer.Address, t.Customer.PhoneNumber) : null,
            t.Attachments.Where(a => a.TicketMessageId == null).Select(Attachment).ToList(),
            t.Messages.OrderBy(m => m.CreatedAt).Select(m => new MessageDto(
                m.Id, Author(m), m.IsStaff, m.Body, m.CreatedAt,
                t.Attachments.Where(a => a.TicketMessageId == m.Id).Select(Attachment).ToList())).ToList());
    }
}
