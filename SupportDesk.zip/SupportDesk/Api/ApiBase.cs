using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace SupportDesk.Api;

public static class ApiAuth
{
    /// <summary>The website's cookie and API clients' JWT bearer token are both accepted.</summary>
    public const string Schemes = IdentityConstants.ApplicationScheme + "," + JwtBearerDefaults.AuthenticationScheme;
}

[ApiController]
[Authorize(AuthenticationSchemes = ApiAuth.Schemes)]
[ServiceFilter(typeof(ApiCsrfFilter))]
[Produces("application/json")]
public abstract class ApiBase : ControllerBase { }

/// <summary>
/// Requests authenticated by the browser cookie must carry the anti-forgery header (the pages send it).
/// Requests authenticated by an explicit "Authorization: Bearer" token are not forgeable by other sites, so they skip it.
/// </summary>
public class ApiCsrfFilter : IAsyncAuthorizationFilter
{
    private readonly IAntiforgery _antiforgery;

    public ApiCsrfFilter(IAntiforgery antiforgery) => _antiforgery = antiforgery;

    public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
    {
        var request = context.HttpContext.Request;

        if (HttpMethods.IsGet(request.Method) || HttpMethods.IsHead(request.Method) ||
            HttpMethods.IsOptions(request.Method) || HttpMethods.IsTrace(request.Method))
            return;

        if (request.Headers.Authorization.ToString().StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            return;

        try
        {
            await _antiforgery.ValidateRequestAsync(context.HttpContext);
        }
        catch (AntiforgeryValidationException)
        {
            context.Result = new ObjectResult(new ProblemDetails
            {
                Status = StatusCodes.Status400BadRequest,
                Title = "The security token is missing or has expired. Refresh the page and try again."
            })
            { StatusCode = StatusCodes.Status400BadRequest };
        }
    }
}

public class JwtSettings
{
    public string Key { get; set; } = string.Empty;
    public string Issuer { get; set; } = "SupportDesk";
    public string Audience { get; set; } = "SupportDeskApi";
    public int ExpiryMinutes { get; set; } = 480;
}
