using System.ComponentModel.DataAnnotations;
using SupportDesk.Models;

namespace SupportDesk.Api;

// ---- Auth / profile ----
public record UserDto(string Id, string FullName, string Email, string? CompanyName, string? Address,
    string? PhoneNumber, bool WhatsAppOptIn, string[] Roles);
public record TokenResponse(string AccessToken, string TokenType, DateTime ExpiresAtUtc, UserDto User);

public class RegisterRequest
{
    [Required, StringLength(100)] public string FullName { get; set; } = string.Empty;
    [Required, EmailAddress] public string Email { get; set; } = string.Empty;
    [Required, StringLength(100, MinimumLength = 8)] public string Password { get; set; } = string.Empty;
    [StringLength(200)] public string? CompanyName { get; set; }
    [StringLength(500)] public string? Address { get; set; }
    [StringLength(30)] public string? PhoneNumber { get; set; }
    public bool WhatsAppOptIn { get; set; }
}

public class LoginRequest
{
    [Required, EmailAddress] public string Email { get; set; } = string.Empty;
    [Required] public string Password { get; set; } = string.Empty;
    public bool RememberMe { get; set; }
}

public class ProfileRequest
{
    [Required, StringLength(100)] public string FullName { get; set; } = string.Empty;
    [StringLength(200)] public string? CompanyName { get; set; }
    [StringLength(500)] public string? Address { get; set; }
    [StringLength(30)] public string? PhoneNumber { get; set; }
    public bool WhatsAppOptIn { get; set; }
}

public class ChangePasswordRequest
{
    [Required] public string CurrentPassword { get; set; } = string.Empty;
    [Required, StringLength(100, MinimumLength = 8)] public string NewPassword { get; set; } = string.Empty;
}

// ---- Products ----
public record ProductOption(int Id, string Name, string? Description);
public record ProductDto(int Id, string Name, string? Description, bool IsActive, int TicketCount);

public class ProductRequest
{
    [Required, StringLength(120)] public string Name { get; set; } = string.Empty;
    [StringLength(500)] public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
}

// ---- Tickets ----
public record AttachmentDto(int Id, string FileName, string ContentType, long SizeBytes, string Url, bool IsImage);
public record MessageDto(int Id, string Author, bool IsStaff, string Body, DateTime CreatedAt, List<AttachmentDto> Attachments);
public record CustomerDto(string Name, string Email, string? CompanyName, string? Address, string? PhoneNumber);

public record TicketSummaryDto(int Id, string Token, string Subject, string Product, string Priority,
    string Status, string? CustomerName, string? CustomerCompany, DateTime CreatedAt, DateTime UpdatedAt);

public record TicketDetailDto(int Id, string Token, string Subject, string Description, string Product,
    string Priority, string Status, DateTime CreatedAt, DateTime UpdatedAt, DateTime? ClosedAt,
    CustomerDto? Customer, List<AttachmentDto> Attachments, List<MessageDto> Messages);

public record TicketCreatedDto(int Id, string Token, string? Warning);

public record TrackDto(string Token, string Subject, string Product, string Priority, string Status,
    DateTime CreatedAt, DateTime UpdatedAt);

public class CreateTicketRequest
{
    [Range(1, int.MaxValue, ErrorMessage = "Choose the product this is about.")]
    public int ProductId { get; set; }

    [Required, StringLength(200)] public string Subject { get; set; } = string.Empty;

    [Required, StringLength(4000, MinimumLength = 10, ErrorMessage = "Please describe the problem in at least 10 characters.")]
    public string Description { get; set; } = string.Empty;

    public TicketPriority Priority { get; set; } = TicketPriority.Medium;

    public List<IFormFile>? Files { get; set; }
}

public class ReplyRequest
{
    [Required, StringLength(4000)] public string Body { get; set; } = string.Empty;
    public List<IFormFile>? Files { get; set; }
}

public class UpdateTicketRequest
{
    public TicketStatus Status { get; set; }
    [StringLength(4000)] public string? Reply { get; set; }
    public List<IFormFile>? Files { get; set; }
}

// ---- Admin ----
public record PagedResult<T>(List<T> Items, int Page, int TotalPages, int Total);
public record ProductStatDto(string Name, int Total, int Unresolved);
public record DashboardDto(int Total, int Open, int InProgress, int Closed, int UrgentUnresolved,
    int CreatedToday, List<ProductStatDto> Products);

// ---- Users and login history ----
public record LoginHistoryDto(int Id, string? UserName, string Email, string UserType, string Event,
    string? Reason, string? IpAddress, string Device, string Method, DateTime CreatedAt);

public record AdminUserDto(string Id, string FullName, string Email, string? CompanyName, string? Address,
    string? PhoneNumber, string[] Roles, bool IsDisabled, DateTime CreatedAt, DateTime? LastSignInAt, int TicketCount);

public class CreateAdminRequest
{
    [Required, StringLength(100)] public string FullName { get; set; } = string.Empty;
    [Required, EmailAddress] public string Email { get; set; } = string.Empty;
    [Required, StringLength(100, MinimumLength = 8)] public string Password { get; set; } = string.Empty;
    [StringLength(200)] public string? CompanyName { get; set; }
}

public class ResetPasswordRequest
{
    [Required, StringLength(100, MinimumLength = 8)] public string NewPassword { get; set; } = string.Empty;
}

// ---- Reports ----
public class ReportFilter
{
    public TicketStatus? Status { get; set; }
    public DateOnly? From { get; set; }
    public DateOnly? To { get; set; }
    public int? ProductId { get; set; }
    public TicketPriority? Priority { get; set; }
    public string? Q { get; set; }
    public int Page { get; set; } = 1;
}

public record ReportSummaryDto(int Total, int Open, int InProgress, int Closed, int Matching, double? AvgResolutionHours);
public record ReportPriorityDto(string Priority, int Count);
public record ReportRowDto(int Id, string Token, string Subject, string Product, string Priority, string Status,
    string Customer, string? Company, string Email, DateTime CreatedAt, DateTime UpdatedAt, DateTime? ClosedAt);
public record TicketReportDto(ReportSummaryDto Summary, List<ReportPriorityDto> ByPriority, PagedResult<ReportRowDto> Rows);
