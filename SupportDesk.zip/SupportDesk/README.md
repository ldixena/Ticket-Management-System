# Support Desk (ASP.NET Core 8 MVC, SQL Server, EF Core, Identity, MailKit)

## 1. Configure
Edit `appsettings.json` (or better, use user-secrets) for:

- `ConnectionStrings:DefaultConnection` (SQL Server)
- `Smtp` (Host, Port, Username, Password, FromAddress, SupportInbox)
- `AdminSeed` (Email, Password) to create the first admin on startup

```
dotnet user-secrets init
dotnet user-secrets set "Smtp:Host" "smtp.yourprovider.com"
dotnet user-secrets set "Smtp:Username" "..."
dotnet user-secrets set "Smtp:Password" "..."
dotnet user-secrets set "AdminSeed:Email" "admin@yourcompany.com"
dotnet user-secrets set "AdminSeed:Password" "ChangeMe-123"
```

## 2. Create the database
```
dotnet tool install --global dotnet-ef
dotnet restore
dotnet ef migrations add InitialCreate
dotnet ef database update      # optional: the app also migrates on startup
```

If you already created `InitialCreate` before attachments were added, add a second migration instead:
```
dotnet ef migrations add AddAttachments
dotnet ef database update
```

## 3. Run
```
dotnet run
```
Roles `Admin` and `Customer` are created on first start. New registrations are Customers.
To promote an existing user without AdminSeed, insert a row into `AspNetUserRoles`
for the user and the `Admin` role.

## Routes
| Page | URL |
|---|---|
| Home | `/` |
| Register / Sign in | `/Account/Register`, `/Account/Login` |
| Raise ticket | `/Tickets/Create` |
| My tickets | `/Tickets` |
| Ticket details | `/Tickets/Details/{id}` |
| Track by token | `/track?token=TKT-XXXXX-XXXXX` |
| Admin dashboard | `/Admin` |
| Manage ticket | `/Admin/Manage/{id}` |
| Products | `/Products` |

## Attachments
- Customers can attach files when raising a ticket and on every reply. Admins can attach files to replies on Manage Ticket.
- Limits are in `appsettings.json` under `Attachments` (5 files per upload, 10 MB each by default). The request limit in `Program.cs` (60 MB) must stay above files x size. If you host on IIS, also raise `maxAllowedContentLength` in web.config.
- Files are saved under `App_Data/uploads/{ticketId}/` with random names, outside `wwwroot`. Back this folder up with the database, and mount it on persistent storage if you deploy to a container.
- Files are served only through `/attachments/{id}`, and only to the ticket's owner and admins. Images and PDFs open in the browser. Everything else downloads.
- Executables, scripts, HTML and SVG are rejected (see `Blocked` in `Services/AttachmentService.cs`). Consider adding virus scanning before production.

## WhatsApp notifications (Meta WhatsApp Business Cloud API)
Customers who add a number and tick the WhatsApp box (Register or Account menu > Profile and notifications) get WhatsApp messages in addition to email: ticket created, and every staff reply or status change. The support number gets an alert for new tickets and customer replies.

Setup:
1. In Meta Business Manager, create a WhatsApp Business account and add a phone number. Note its **Phone number ID**.
2. Create a System User and generate a permanent access token with the `whatsapp_business_messaging` permission.
3. Create these three **Utility** message templates (language English) and wait for approval. Variable counts must match exactly.

   `ticket_created`: Hi {{1}}, we received your ticket {{2}} about {{3}}. Track it here: {{4}}

   `ticket_updated`: Hi {{1}}, your ticket {{2}} has an update. Status: {{3}}. Message from our team: {{4}} View it here: {{5}}

   `ticket_support_alert`: Ticket {{1}} ({{2}}) from {{3}}: {{4}} Open it here: {{5}}
4. Fill the `WhatsApp` section of `appsettings.json` (use user-secrets for the token): `Enabled`, `AccessToken`, `PhoneNumberId`, `DefaultCountryCode`, `SupportNumber`.
5. Run a migration for the new opt-in column: `dotnet ef migrations add AddWhatsAppOptIn` then `dotnet ef database update`.

Notes: WhatsApp requires user opt-in (the checkbox) and approved templates for business-started messages. While testing with Meta's free test number you can only message recipients you have verified in the Meta dashboard. Failed sends are logged and never block the ticket. Links point at your site, so set a real HTTPS host in production.

## REST API (`/api`) and how the pages use it
Every page is a thin HTML shell. Its data and every action go through the JSON API, so the website and any other client (mobile app, script) share exactly the same rules.

- **Browser pages** call the API with the sign-in cookie plus an anti-forgery header (`X-CSRF-TOKEN`, read from the page's `<meta name="csrf-token">`). See `wwwroot/js/api.js` and `wwwroot/js/pages.js`.
- **Other clients** call `POST /api/auth/token` with `{ "email": "...", "password": "..." }` and send `Authorization: Bearer <accessToken>` on every request. Bearer requests need no anti-forgery token.
- **Swagger UI** (Development only): `/swagger`. Click Authorize and paste the token.
- Set a real signing key before deploying: `dotnet user-secrets set "Jwt:Key" "<32+ random characters>"`. If it is empty, a random key is generated at startup and tokens stop working after a restart.
- Errors use RFC 7807 problem JSON. Validation errors look like `{ "title": "...", "errors": { "Subject": ["..."] } }`.

| Page | Endpoints it uses |
|---|---|
| Register / Sign in / Sign out | `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/logout` |
| Profile / Change password | `GET /api/auth/me`, `PUT /api/auth/profile`, `POST /api/auth/change-password` |
| Raise ticket | `GET /api/products`, `POST /api/tickets` (multipart: productId, subject, description, priority, files) |
| My tickets | `GET /api/tickets` |
| Ticket details | `GET /api/tickets/{id}`, `POST /api/tickets/{id}/replies` (multipart: body, files) |
| Track by token | `GET /api/track/{token}` (public, rate limited) |
| Admin dashboard | `GET /api/admin/dashboard`, `GET /api/admin/tickets?q=&status=&page=` |
| Manage ticket | `GET /api/admin/tickets/{id}`, `POST /api/admin/tickets/{id}/update` (multipart: status, reply, files) |
| Products | `GET/POST /api/admin/products`, `GET/PUT /api/admin/products/{id}`, `POST /api/admin/products/{id}/toggle` |
| Files | `GET /api/attachments/{id}` |

Example:
```
curl -X POST https://localhost:5001/api/auth/token -H "Content-Type: application/json" -d '{"email":"you@example.com","password":"..."}'
curl https://localhost:5001/api/tickets -H "Authorization: Bearer <token>"
curl -X POST https://localhost:5001/api/tickets -H "Authorization: Bearer <token>" -F productId=1 -F subject="Login fails" -F description="I get an error after entering my password" -F priority=High -F files=@screenshot.png
```

## Admins, users, login history, reports
- **Several admins:** Admin > Users and admins. Create another admin, make a customer an admin, remove admin rights, or disable an account (it is signed out at once and cannot sign in on the web or with an API token). You can't remove or disable yourself, and the last active admin can't be removed.
- **Passwords can't be decrypted.** Identity stores only a one-way hash, so no one (including you) can read a password back. Admins use **Reset password** on the Users page instead: it sets a new password, ends the user's sessions, clears any lock-out and emails the user (without the password). Users change their own password from the account menu.
- **Login history:** every sign-in, failed attempt, lock-out and sign-out is recorded for admins and customers with time, IP address, device and whether it came from the website or the API. Each user sees their own on Profile and notifications. Admins see everyone's on Admin > Login history (filter by admin/customer, failed only, or search by email, name or IP). Behind a reverse proxy or load balancer, enable `UseForwardedHeaders` so the real client IP is stored instead of the proxy's.
- **Company name and address** are collected at registration, editable on the profile, and shown to admins on the ticket and user pages. Admins can search tickets and users by company.
- **Ticket report:** Admin > Reports. Choose All, Open, In progress or Closed, plus created-date range, product, priority and a text search. It shows totals for all three statuses, the average time to close, a priority breakdown and the matching tickets. Download CSV (opens in Excel) or Print. Dates are UTC.
- Migration for these changes: `dotnet ef migrations add AddUserDetailsAndLoginHistory` then `dotnet ef database update`.
